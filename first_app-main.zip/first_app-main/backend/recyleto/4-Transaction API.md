# Transaction API Documentation

## Overview
Transaction API endpoints for managing pharmacy transactions, cart operations, and checkout processes.

**Base URL:** `/transactions`

**Authentication:** All endpoints require valid authentication token.

---

## Cart Management Endpoints

### 1. Add to Cart
**POST** `/transactions/cart`

Adds an item to the shopping cart.

#### Request Body
```json
{
  "medicineId": "medicine_id_here",        
  "quantity": 5,                           
  "transactionType": "sale",               // Optional: "sale" | "purchase" | "return" | "adjustment" | "transfer"
  "price": 29.99                           
}
```

#### Response
```json
{
  "success": true,
  "message": "Item added to cart",
  "data": {
    "cartItem": {
      // cart item details
    }
  }
}
```

---

### 2. Get Cart
**GET** `/transactions/cart`

Retrieves current cart contents.

#### Response
```json
{
  "success": true,
  "data": {
    "items": [
      // cart items
    ],
    "totalAmount": 150.50
  }
}
```

---

### 3. Update Cart Item
**PUT** `/transactions/cart/:itemId`

Updates a specific item in the cart.

#### URL Parameters
- `itemId`: Cart item identifier

#### Request Body
```json
{
  "quantity": 3,
  "price": 25.00
}
```

#### Response
```json
{
  "success": true,
  "message": "Cart item updated",
  "data": {
    "cartItem": {
      // updated cart item details
    }
  }
}
```

---

### 4. Remove Cart Item
**DELETE** `/transactions/cart/:itemId`

Removes a specific item from the cart.

#### URL Parameters
- `itemId`: Cart item identifier

#### Response
```json
{
  "success": true,
  "message": "Item removed from cart"
}
```

---

### 5. Clear Cart
**DELETE** `/transactions/cart`

Removes all items from the cart.

#### Response
```json
{
  "success": true,
  "message": "Cart cleared"
}
```

---

## Transaction Endpoints

### 6. Checkout Cart
**POST** `/transactions/checkout`
**POST** `/transactions/`

Processes cart checkout and creates a transaction.

#### Request Body
```json
{
  "transactionType": "sale",               
  "description": "Transaction description", 
  "customerName": "John Doe",              
  "customerPhone": "+1-234-567-8900",   
  "paymentMethod": "cash",                 
  "items": [                               
    {
      "medicineId": "med_123",             
      "quantity": 2,                       
      "price": 15.50                       
    }
  ],
  "totalAmount": 31.00                     
}
```

#### Response
```json
{
  "success": true,
  "message": "Transaction completed successfully",
  "data": {
    "transactionId": "txn_123456789",
    "status": "completed",
    "totalAmount": 31.00
  }
}
```

---

### 7. Get Transactions
**GET** `/transactions/`

Retrieves transaction list with optional filtering and pagination.

#### Query Parameters
```
search: "search_term"          // Optional (max 100 characters)
startDate: "2024-01-01T00:00:00.000Z"  // Optional (ISO8601 date)
endDate: "2024-12-31T23:59:59.000Z"    // Optional (ISO8601 date)
status: "completed"            // Optional: "pending" | "completed" | "cancelled"
page: 1                        // Optional (integer, min 1)
limit: 20                      // Optional (integer, 1-100)
```

#### Response
```json
{
  "success": true,
  "data": {
    "transactions": [
      // transaction objects
    ],
    "pagination": {
      "page": 1,
      "limit": 20,
      "total": 150,
      "pages": 8
    }
  }
}
```

---

### 8. Get Transaction by ID
**GET** `/transactions/:id`

Retrieves a specific transaction by its ID.

#### URL Parameters
- `id`: Transaction identifier

#### Response
```json
{
  "success": true,
  "data": {
    "transaction": {
      "id": "txn_123456789",
      "transactionType": "sale",
      "status": "completed",
      "items": [
        // transaction items
      ],
      "totalAmount": 75.50,
      "createdAt": "2024-01-15T10:30:00.000Z"
    }
  }
}
```

---

## Validation Rules

### Cart Operations
- `medicineId`: Required string
- `quantity`: Required integer, minimum 1
- `transactionType`: Optional, must be one of: "sale", "purchase", "return", "adjustment", "transfer"
- `price`: Optional float, minimum 0

### Transaction Creation
- `transactionType`: Required, must be one of: "sale", "purchase", "return", "adjustment", "transfer"
- `description`: Optional, maximum 500 characters
- `customerName`: Optional, maximum 100 characters
- `customerPhone`: Optional, maximum 20 characters, valid phone format
- `paymentMethod`: Optional, must be one of: "cash", "card", "mobile_money", "bank_transfer", "credit"
- `items`: Required array with minimum 1 item
- `items.*.medicineId`: Required string for each item
- `items.*.quantity`: Required integer, minimum 1 for each item
- `items.*.price`: Optional float, minimum 0 for each item
- `totalAmount`: Optional float, minimum 0

### Query Parameters
- `search`: Optional, maximum 100 characters
- `startDate`: Optional, valid ISO8601 date format
- `endDate`: Optional, valid ISO8601 date format
- `status`: Optional, must be one of: "pending", "completed", "cancelled"
- `page`: Optional integer, minimum 1
- `limit`: Optional integer, between 1 and 100

---

## Error Responses

### Authentication Error (401)
```json
{
  "success": false,
  "message": "Authentication required"
}
```

### Validation Error (400)
```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [
    {
      "field": "medicineId",
      "message": "Medicine ID is required"
    }
  ]
}
```

### Not Found Error (404)
```json
{
  "success": false,
  "message": "Transaction not found"
}
```