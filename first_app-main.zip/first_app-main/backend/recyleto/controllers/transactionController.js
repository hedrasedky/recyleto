const Transaction = require('../models/Transaction');
const Medicine = require('../models/Medicine');
const Cart = require('../models/Cart');
const CartItem = require('../models/CartItem');
const mongoose = require('mongoose');
const { generateTransactionNumber } = require('../utils/helpers'); // ✅ use helper

// Get all transactions with search and filters
exports.getTransactions = async (req, res) => {
  try {
    const { search, startDate, endDate, status, transactionType, page = 1, limit = 10 } = req.query;
    const pharmacyId = req.user.pharmacyId || req.user._id;

    let query = { pharmacyId };

    if (search) {
      query.$or = [
        { transactionRef: new RegExp(search, 'i') },
        { description: new RegExp(search, 'i') },
        { customerName: new RegExp(search, 'i') },
        { 'items.medicineName': new RegExp(search, 'i') }
      ];
    }

    if (startDate || endDate) {
      query.createdAt = {};
      if (startDate) query.createdAt.$gte = new Date(startDate);
      if (endDate) query.createdAt.$lte = new Date(endDate);
    }

    if (status) query.status = status;
    if (transactionType) query.transactionType = transactionType;

    const skip = (page - 1) * limit;

    const transactions = await Transaction.find(query)
      .select('-__v')
      .populate('items.medicineId', 'name genericName form price')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Transaction.countDocuments(query);

    res.status(200).json({
      success: true,
      data: transactions,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Get transactions error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching transactions'
    });
  }
};

// Get transaction by ID with full details
exports.getTransactionById = async (req, res) => {
  try {
    const { id } = req.params;
    const pharmacyId = req.user.pharmacyId || req.user._id;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ success: false, message: 'Invalid transaction ID' });
    }

    const transaction = await Transaction.findOne({ _id: id, pharmacyId })
      .populate('items.medicineId', 'name genericName form price');

    if (!transaction) {
      return res.status(404).json({ success: false, message: 'Transaction not found' });
    }

    res.status(200).json({ success: true, data: transaction });
  } catch (error) {
    console.error('Get transaction error:', error);
    res.status(500).json({ success: false, message: 'Server error while fetching transaction' });
  }
};

// Add medicine to cart
exports.addToCart = async (req, res) => {
  try {
    const { medicineId, quantity, transactionType = 'sale' } = req.body;
    const pharmacyId = req.user.pharmacyId || req.user._id;

    const medicine = await Medicine.findById(medicineId);
    if (!medicine) return res.status(404).json({ success: false, message: 'Medicine not found' });

    if (transactionType === 'sale' && medicine.quantity < quantity) {
      return res.status(400).json({ success: false, message: `Insufficient stock. Available: ${medicine.quantity}` });
    }

    let cart = await Cart.findOne({ pharmacyId, transactionType, status: 'active' });
    if (!cart) {
      cart = new Cart({ pharmacyId, transactionType });
      await cart.save();
    }

    const itemData = {
      medicineId: medicine._id,
      medicineName: medicine.name,
      genericName: medicine.genericName,
      form: medicine.form,
      packSize: medicine.packSize,
      quantity: parseInt(quantity),
      unitPrice: medicine.price,
      expiryDate: medicine.expiryDate,
      batchNumber: medicine.batchNumber,
      manufacturer: medicine.manufacturer,
      pharmacyId
    };

    await cart.addItem(itemData);
    await cart.save();

    const populatedCart = await cart.getPopulatedCart();
    res.status(200).json({ success: true, message: 'Medicine added to cart', data: populatedCart });

  } catch (error) {
    console.error('Add to cart error:', error);
    res.status(500).json({ success: false, message: 'Error adding to cart' });
  }
};

// Get cart
exports.getCart = async (req, res) => {
  try {
    const pharmacyId = req.user.pharmacyId || req.user._id;
    const { transactionType = 'sale' } = req.query;

    let cart = await Cart.findOne({ pharmacyId, transactionType, status: 'active' });
    if (!cart) {
      return res.status(200).json({ success: true, data: { items: [], totalAmount: 0, totalItems: 0, totalQuantity: 0 } });
    }

    const populatedCart = await cart.getPopulatedCart();
    res.status(200).json({ success: true, data: populatedCart });

  } catch (error) {
    console.error('Get cart error:', error);
    res.status(500).json({ success: false, message: 'Error fetching cart' });
  }
};

// Update cart item
exports.updateCartItem = async (req, res) => {
  try {
    const pharmacyId = req.user.pharmacyId || req.user._id;
    const { itemId } = req.params;
    const { quantity, unitPrice } = req.body;

    const cartItem = await CartItem.findOne({ _id: itemId, pharmacyId });
    if (!cartItem) return res.status(404).json({ success: false, message: 'Cart item not found' });

    if (quantity !== undefined && cartItem.transactionType === 'sale') {
      const medicine = await Medicine.findById(cartItem.medicineId);
      if (medicine.quantity < quantity) {
        return res.status(400).json({ success: false, message: `Insufficient stock. Available: ${medicine.quantity}` });
      }
    }

    if (quantity !== undefined) await cartItem.updateQuantity(parseInt(quantity));
    if (unitPrice !== undefined) await cartItem.updatePrice(parseFloat(unitPrice));

    const cart = await Cart.findById(cartItem.cartId);
    await cart.updateTotals();
    const populatedCart = await cart.getPopulatedCart();

    res.status(200).json({ success: true, message: 'Cart item updated', data: populatedCart });

  } catch (error) {
    console.error('Update cart item error:', error);
    res.status(500).json({ success: false, message: 'Error updating cart item' });
  }
};

// Remove item from cart
exports.removeFromCart = async (req, res) => {
  try {
    const pharmacyId = req.user.pharmacyId || req.user._id;
    const { itemId } = req.params;

    const cartItem = await CartItem.findOne({ _id: itemId, pharmacyId });
    if (!cartItem) return res.status(404).json({ success: false, message: 'Cart item not found' });

    const cart = await Cart.findById(cartItem.cartId);
    await cart.removeItem(itemId);
    await cart.save();

    const populatedCart = await cart.getPopulatedCart();
    res.status(200).json({ success: true, message: 'Item removed from cart', data: populatedCart });

  } catch (error) {
    console.error('Remove from cart error:', error);
    res.status(500).json({ success: false, message: 'Error removing from cart' });
  }
};

// Clear cart
exports.clearCart = async (req, res) => {
  try {
    const pharmacyId = req.user.pharmacyId || req.user._id;
    const { transactionType = 'sale' } = req.body;

    const cart = await Cart.findOne({ pharmacyId, transactionType, status: 'active' });
    if (cart) {
      await cart.clearCart();
      await cart.save();
    }

    res.status(200).json({ success: true, message: 'Cart cleared successfully' });

  } catch (error) {
    console.error('Clear cart error:', error);
    res.status(500).json({ success: false, message: 'Error clearing cart' });
  }
};

// Checkout cart
exports.checkoutCart = async (req, res) => {
  try {
    const pharmacyId = req.user.pharmacyId || req.user._id;
    const { transactionType, description, customerName, customerPhone, paymentMethod } = req.body;

    // Find active cart
    const cart = await Cart.findOne({ pharmacyId, transactionType: transactionType || 'sale', status: 'active' })
      .populate({
        path: 'items',
        select: 'medicineId medicineName packSize quantity unitPrice totalPrice expiryDate batchNumber'
      });

    if (!cart) return res.status(400).json({ success: false, message: 'No active cart found' });
    if (!cart.items || cart.items.length === 0) return res.status(400).json({ success: false, message: 'Cart is empty' });

    const transactionItems = cart.items.map(item => ({
      medicineId: item.medicineId,
      medicineName: item.medicineName,
      packSize: item.packSize,
      quantity: item.quantity,
      unitPrice: item.unitPrice,
      totalPrice: item.totalPrice,
      expiryDate: item.expiryDate,
      batchNumber: item.batchNumber
    }));

    const totalAmount = cart.totalAmount || transactionItems.reduce((sum, item) => sum + item.totalPrice, 0);

    // Generate numbers
    const transactionNumber = await generateTransactionNumber(transactionType || 'sale');
    const transactionRef = `TXN-${Math.random().toString(36).substring(2, 9).toUpperCase()}`;

    // Create transaction
    const transaction = new Transaction({
      pharmacyId,
      transactionType: transactionType || cart.transactionType,
      transactionNumber,
      transactionRef,        // <-- important for refund
      description,
      items: transactionItems,
      customerInfo: {
        name: customerName,
        phone: customerPhone
      },
      paymentMethod,
      totalAmount
    });

    await transaction.save();

    // Update stock for sale transactions
    for (const item of transaction.items) {
      if (transaction.transactionType === 'sale') {
        await Medicine.findByIdAndUpdate(item.medicineId, { $inc: { quantity: -item.quantity } });
      }
    }

    // Clear cart
    await cart.clearCart();
    await cart.save();

    res.status(200).json({ success: true, message: 'Checkout successful', data: transaction });

  } catch (error) {
    console.error('Checkout error:', error);
    res.status(500).json({ success: false, message: 'Error during checkout' });
  }
};

