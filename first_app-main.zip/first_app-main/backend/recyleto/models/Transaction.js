const mongoose = require('mongoose');
const Counter = require('./Counter'); // ✅ Counter model to generate transaction numbers

const transactionItemSchema = new mongoose.Schema({
    medicineId: { type: mongoose.Schema.Types.ObjectId, ref: 'Medicine', required: true },
    medicineName: { type: String, required: true },
    packSize: { type: String, required: true },
    quantity: { type: Number, required: true, min: 1 },
    unitPrice: { type: Number, required: true, min: 0 },
    totalPrice: { type: Number, required: true, min: 0 },
    expiryDate: { type: Date },
    batchNumber: { type: String }
});

const transactionSchema = new mongoose.Schema({
    pharmacyId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    transactionType: {
        type: String,
        required: true,
        enum: ['sale', 'purchase', 'return', 'adjustment', 'transfer'],
        default: 'sale'
    },
    transactionNumber: { type: String, required: true, unique: true }, // ✅ generated via Counter
    transactionRef: { type: String, unique: true, required: true },
    description: { type: String, trim: true, maxlength: 500 },
    items: [transactionItemSchema],
    subtotal: { type: Number, required: true },
    tax: { type: Number, default: 0 },
    discount: { type: Number, default: 0 },
    totalAmount: { type: Number, required: true, min: 0 },
    customerInfo: {
        name: { type: String, trim: true },
        phone: { type: String, trim: true }
    },
    paymentMethod: {
        type: String,
        enum: ['cash', 'card', 'mobile_money', 'bank_transfer', 'credit', 'digital_wallet'],
        default: 'cash'
    },
    status: {
        type: String,
        enum: ['completed', 'draft', 'cancelled'], // ✅ Updated enum values
        default: 'completed' // ✅ Default value as requested
    },
    transactionDate: { type: Date, default: Date.now },
    refunds: [{
        refundId: { type: mongoose.Schema.Types.ObjectId, ref: 'Refund' },
        amount: { type: Number, required: true, min: 0 },
        date: { type: Date, default: Date.now },
        reason: { type: String, trim: true }
    }]
}, { timestamps: true });

// ------------------------
// Pre-save: generate unique transactionNumber if new
// ------------------------
transactionSchema.pre('save', async function(next) {
    if (this.isNew) {
        try {
            const counter = await Counter.findOneAndUpdate(
                { name: this.transactionType },
                { $inc: { seq: 1 } },
                { new: true, upsert: true }
            );
            this.transactionNumber = `${this.transactionType.toUpperCase().slice(0,3)}-${String(counter.seq).padStart(6, '0')}`;
        } catch (err) {
            return next(err);
        }
    }

    // Calculate totals
    this.subtotal = this.items.reduce((total, item) => total + (item.totalPrice || 0), 0);
    this.totalAmount = Math.max(0, this.subtotal + (this.tax || 0) - (this.discount || 0));

    // Update status based on refunds (only if transaction is completed)
    if (this.status === 'completed') {
        const totalRefunded = this.refunds.reduce((total, refund) => total + (refund.amount || 0), 0);
        if (totalRefunded >= this.totalAmount && totalRefunded > 0) {
            this.status = 'refunded';
        } else if (totalRefunded > 0) {
            this.status = 'partially_refunded';
        }
    }

    next();
});

// ------------------------
// Virtual for total refund amount
// ------------------------
transactionSchema.virtual('totalRefunded').get(function() {
    return this.refunds.reduce((total, refund) => total + (refund.amount || 0), 0);
});

// ------------------------
// Method to check if transaction can be refunded
// ------------------------
transactionSchema.methods.canRefund = function() {
    return this.status === 'completed' && this.totalRefunded < this.totalAmount;
};

module.exports = mongoose.model('Transaction', transactionSchema);