const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { validateResult } = require('../middleware/validateResult');
const { loginValidator, forgotPasswordValidator, resetPasswordValidator } = require('../validators/authValidator');
const { registerPharmacyValidator } = require('../validators/pharmacyValidator');
const { upload } = require('../middleware/upload');
const { authenticate } = require('../middleware/auth');

// Handle file upload errors
const handleUploadError = (error, req, res, next) => {
    if (error) {
        return res.status(400).json({
            success: false,
            message: error.message
        });
    }
    next();
};

router.post('/login', loginValidator, validateResult, authController.login);
router.post('/forgot-password', forgotPasswordValidator, validateResult, authController.forgotPassword);
router.post('/reset-password', resetPasswordValidator, validateResult, authController.resetPassword);
router.post('/register-pharmacy', 
    upload.single('licenseImage'),
    handleUploadError,
    registerPharmacyValidator,
    validateResult,
    authController.registerPharmacy
);

// 2FA routes
router.post('/2fa/enable', authenticate, authController.enable2FA);
router.post('/2fa/verify', authenticate, authController.verify2FA);
router.post('/2fa/disable', authenticate, authController.disable2FA);

module.exports = router;