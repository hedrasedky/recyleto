// routes/businessSettings.js - CORRECT VERSION
const express = require('express');
const router = express.Router();
const { getBusinessSettings, updateBusinessSettings } = require('../controllers/businessSettingsController');
const { authenticate, authorize } = require('../middleware/auth');

// CORRECT: Pass roles as individual arguments
router.get('/', authenticate, authorize('admin', 'pharmacy', 'pharmacist'), getBusinessSettings);
router.put('/', authenticate, authorize('admin', 'pharmacy', 'pharmacist'), updateBusinessSettings);

// ALTERNATIVE CORRECT: Pass roles as a single array
// router.get('/', authenticate, authorize(['admin', 'pharmacy', 'pharmacist']), getBusinessSettings);
// router.put('/', authenticate, authorize(['admin', 'pharmacy', 'pharmacist']), updateBusinessSettings);

module.exports = router;