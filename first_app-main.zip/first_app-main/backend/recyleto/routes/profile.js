const express = require('express');
const router = express.Router();
const profileController = require('../controllers/profileController');
const { updateProfileValidator, changePasswordValidator } = require('../validators/profileValidator');
const { validateResult } = require('../middleware/validateResult');
const { authenticate } = require('../middleware/auth');
const { uploadLicense } = require('../middleware/upload'); // ✅ destructured

// Apply authentication middleware
router.use(authenticate);

// Get current user profile
router.get('/', profileController.getProfile);

// Update profile info with optional license image
router.put(
    '/',
    (req, res, next) => uploadLicense.single('licenseImage')(req, res, next), // ✅ wrapper
    updateProfileValidator,
    validateResult,
    profileController.updateProfile
);

// Change password
router.post(
    '/change-password',
    changePasswordValidator,
    validateResult,
    profileController.changePassword
);

module.exports = router;
