const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../middleware/auth');
const { validateResult } = require('../middleware/validateResult');
const { medicineRequestValidator } = require('../validators/requestValidator');
const { uploadRequest } = require('../middleware/upload'); // FIXED: Changed from uploadMedicineRequestImage to uploadRequest
const {
  createMedicineRequest,
  getPharmacyMedicineRequests,
  getUserMedicineRequests,
  getMedicineRequestDetails
} = require('../controllers/requestController');

// Medicine request routes
router.post(
  '/medicine',
  authenticate,
  uploadRequest.single('image'), // FIXED: Changed from uploadMedicineRequestImage to uploadRequest
  medicineRequestValidator,
  validateResult,
  createMedicineRequest
);

router.get('/medicine/user', authenticate, getUserMedicineRequests);
router.get('/medicine/:requestId', authenticate, getMedicineRequestDetails);

// Pharmacy staff routes for medicine requests (pharmacists, admins, assistants)
router.get(
  '/medicine/pharmacy/all',
  authenticate,
  authorize(['pharmacist', 'admin', 'assistant']),
  getPharmacyMedicineRequests
);

module.exports = router;