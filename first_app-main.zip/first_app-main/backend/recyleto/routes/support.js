const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const supportController = require('../controllers/supportController');
const { authenticate, authorize } = require('../middleware/auth');
const { uploadSupport } = require('../middleware/upload');
const {
  createSupportTicketValidator,
  addMessageValidator,
  updateTicketStatusValidator
} = require('../validators/supportValidator');
const { validateResult } = require('../middleware/validateResult');

// Test route to check if Counter works - remove after testing
router.get('/test-counter', async (req, res) => {
  try {
    const Counter = mongoose.model('Counter');
    const counter = await Counter.findOneAndUpdate(
      { name: 'testCounter' },
      { $inc: { seq: 1 } },
      { new: true, upsert: true }
    );
    res.json({ 
      success: true, 
      message: 'Counter test successful',
      counter 
    });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      message: 'Counter test failed',
      error: error.message 
    });
  }
});

// User routes
router.post(
  '/tickets',
  authenticate,
  uploadSupport.array('attachments', 3),
  ...createSupportTicketValidator,
  validateResult,
  supportController.createTicket
);

router.get(
  '/tickets',
  authenticate,
  supportController.getUserTickets
);

router.get(
  '/tickets/:ticketId',
  authenticate,
  supportController.getTicket
);

router.post(
  '/tickets/:ticketId/messages',
  authenticate,
  uploadSupport.array('attachments', 3),
  ...addMessageValidator,
  validateResult,
  supportController.addMessage
);

// Admin routes
router.get(
  '/admin/tickets',
  authenticate,
  authorize(['admin']),
  supportController.getAllTickets
);

router.patch(
  '/admin/tickets/:ticketId/status',
  authenticate,
  authorize(['admin']),
  ...updateTicketStatusValidator,
  validateResult,
  supportController.updateTicketStatus
);

router.post(
  '/admin/tickets/:ticketId/messages',
  authenticate,
  authorize(['admin']),
  uploadSupport.array('attachments', 3),
  ...addMessageValidator,
  validateResult,
  supportController.addAdminResponse
);

router.get(
  '/admin/support-stats',
  authenticate,
  authorize(['admin']),
  supportController.getSupportStats
);

module.exports = router;