const express = require('express');
const router = express.Router();
const transactionController = require('../controllers/transactionController');
const { protect } = require('../middleware/auth');
const { validateResult } = require('../middleware/validateResult');
const { 
  createTransactionValidator, 
  cartValidator, 
  transactionQueryValidator 
} = require('../validators/transactionValidator');

// Apply authentication to all routes
router.use(protect);

// Cart operations
router.post('/cart', cartValidator, validateResult, transactionController.addToCart);
router.get('/cart', transactionController.getCart);
router.put('/cart/:itemId', transactionController.updateCartItem);
router.delete('/cart/:itemId', transactionController.removeFromCart);
router.delete('/cart', transactionController.clearCart);

// Transaction operations
router.post('/checkout', createTransactionValidator, validateResult, transactionController.checkoutCart);
router.post('/', createTransactionValidator, validateResult, transactionController.checkoutCart); // Alternative endpoint

// Get all transactions with search and filters
router.get('/', transactionQueryValidator, validateResult, transactionController.getTransactions);

// Get transaction by ID with full details
router.get('/:id', transactionController.getTransactionById);

// Keep your existing transaction routes here for future use
// router.put('/:id', ...);
// router.delete('/:id', ...);
// etc.

module.exports = router;