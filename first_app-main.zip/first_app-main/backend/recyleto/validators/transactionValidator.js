const { body, query } = require('express-validator');

// Query validation for transaction listing/filtering
exports.transactionQueryValidator = [
  query('search')
    .optional()
    .trim()
    .isLength({ max: 100 })
    .withMessage('Search query cannot exceed 100 characters'),
  
  query('startDate')
    .optional()
    .isISO8601()
    .withMessage('Start date must be a valid date'),
  
  query('endDate')
    .optional()
    .isISO8601()
    .withMessage('End date must be a valid date'),
  
  query('status')
    .optional()
    .isIn(['pending', 'completed', 'cancelled'])
    .withMessage('Status must be one of: pending, completed, cancelled'),
  
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Page must be a positive integer'),
  
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('Limit must be between 1 and 100')
];

// Validation for creating transactions
exports.createTransactionValidator = [
  body('transactionType')
    .notEmpty()
    .withMessage('Transaction type is required')
    .isIn(['sale', 'purchase', 'return', 'adjustment', 'transfer'])
    .withMessage('Invalid transaction type. Must be one of: sale, purchase, return, adjustment, transfer'),
  
  body('description')
    .optional()
    .trim()
    .isLength({ max: 500 })
    .withMessage('Description must be less than 500 characters'),
  
  body('customerName')
    .optional()
    .trim()
    .isLength({ max: 100 })
    .withMessage('Customer name must be less than 100 characters'),
  
  body('customerPhone')
    .optional()
    .trim()
    .isLength({ max: 20 })
    .withMessage('Customer phone must be less than 20 characters')
    .matches(/^[+\d\s\-()]+$/)
    .withMessage('Customer phone must contain only numbers, spaces, hyphens, parentheses, and plus sign'),
  
  body('paymentMethod')
    .optional()
    .isIn(['cash', 'card', 'mobile_money', 'bank_transfer', 'credit'])
    .withMessage('Invalid payment method. Must be one of: cash, card, mobile_money, bank_transfer, credit'),
  
  body('items')
    .isArray({ min: 1 })
    .withMessage('Transaction must contain at least one item'),
  
  body('items.*.medicineId')
    .notEmpty()
    .withMessage('Medicine ID is required for all items'),
  
  body('items.*.quantity')
    .isInt({ min: 1 })
    .withMessage('Quantity must be at least 1 for all items'),
  
  body('items.*.price')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Price must be a non-negative number'),
  
  body('totalAmount')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Total amount must be a non-negative number')
];

// Validation for cart operations
exports.cartValidator = [
  body('medicineId')
    .notEmpty()
    .withMessage('Medicine ID is required'),
  
  body('quantity')
    .isInt({ min: 1 })
    .withMessage('Quantity must be at least 1'),
  
  body('transactionType')
    .optional()
    .isIn(['sale', 'purchase', 'return', 'adjustment', 'transfer'])
    .withMessage('Invalid transaction type. Must be one of: sale, purchase, return, adjustment, transfer'),
  
  body('price')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Price must be a non-negative number')
];

// Additional validation for updating transactions
exports.updateTransactionValidator = [
  body('status')
    .optional()
    .isIn(['pending', 'completed', 'cancelled'])
    .withMessage('Status must be one of: pending, completed, cancelled'),
  
  body('description')
    .optional()
    .trim()
    .isLength({ max: 500 })
    .withMessage('Description must be less than 500 characters'),
  
  body('customerName')
    .optional()
    .trim()
    .isLength({ max: 100 })
    .withMessage('Customer name must be less than 100 characters'),
  
  body('customerPhone')
    .optional()
    .trim()
    .isLength({ max: 20 })
    .withMessage('Customer phone must be less than 20 characters')
];

module.exports = exports;