import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../services/api_service.dart';
import '../../utils/app_theme.dart';

class AddMedicineScreen extends StatefulWidget {
  const AddMedicineScreen({super.key});

  @override
  State<AddMedicineScreen> createState() => _AddMedicineScreenState();
}

class _AddMedicineScreenState extends State<AddMedicineScreen> {
  final _formKey = GlobalKey<FormState>();
  final _medicineNameController = TextEditingController();
  final _genericNameController = TextEditingController();
  final _packSizeController = TextEditingController();
  final _quantityController = TextEditingController();
  final _priceController = TextEditingController();
  final _manufacturerController = TextEditingController();
  final _batchNumberController = TextEditingController();
  final _descriptionController = TextEditingController();
  final ApiService _apiService = ApiService();

  String _selectedForm = 'Tablet';
  DateTime _selectedExpiryDate = DateTime.now().add(const Duration(days: 365));
  bool _isOTC = true;
  bool _isLoading = false;

  final List<String> _forms = [
    'Tablet',
    'Capsule',
    'Syrup',
    'Injection',
    'Cream',
    'Ointment',
    'Drops',
    'Inhaler',
    'Patch',
    'Powder',
    'Gel',
    'Lotion',
  ];

  @override
  void dispose() {
    _medicineNameController.dispose();
    _genericNameController.dispose();
    _packSizeController.dispose();
    _quantityController.dispose();
    _priceController.dispose();
    _manufacturerController.dispose();
    _batchNumberController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _selectExpiryDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedExpiryDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 3650)), // 10 years
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: Theme.of(context).colorScheme.copyWith(
                  primary: AppTheme.primaryTeal,
                ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null && picked != _selectedExpiryDate) {
      setState(() {
        _selectedExpiryDate = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        title: const Text(
          'Add Medicine to Recyleto',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: AppTheme.primaryTeal,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            onPressed: _clearForm,
            icon: const Icon(Icons.refresh),
            tooltip: 'Reset Form',
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: Column(
          children: [
            // Header Info
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              color: AppTheme.primaryTeal.withOpacity(0.1),
              child: Column(
                children: [
                  const Icon(
                    Icons.add_box,
                    size: 48,
                    color: AppTheme.primaryTeal,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Add New Medicine to Platform',
                    style: theme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryTeal,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Fill in the details to make this medicine available to other pharmacies',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: AppTheme.darkGray.withOpacity(0.7),
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),

            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Basic Information
                    _buildSectionHeader(
                        'Basic Information', Icons.info_outline),
                    const SizedBox(height: 16),

                    _buildTextField(
                      controller: _medicineNameController,
                      label: 'Medicine Name *',
                      hint: 'e.g., Paracetamol 500mg',
                      icon: Icons.medication,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter medicine name';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    _buildTextField(
                      controller: _genericNameController,
                      label: 'Generic Name *',
                      hint: 'e.g., Acetaminophen',
                      icon: Icons.science,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter generic name';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    _buildFormDropdown(),
                    const SizedBox(height: 16),

                    _buildTextField(
                      controller: _packSizeController,
                      label: 'Pack Size *',
                      hint: 'e.g., 10 tablets, 100ml bottle',
                      icon: Icons.inventory_2,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter pack size';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 24),

                    // Pricing & Inventory
                    _buildSectionHeader(
                        'Pricing & Inventory', Icons.attach_money),
                    const SizedBox(height: 16),

                    Row(
                      children: [
                        Expanded(
                          child: _buildTextField(
                            controller: _quantityController,
                            label: 'Quantity *',
                            hint: '0',
                            icon: Icons.numbers,
                            keyboardType: TextInputType.number,
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly
                            ],
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Enter quantity';
                              }
                              if (int.tryParse(value) == null ||
                                  int.parse(value) <= 0) {
                                return 'Enter valid quantity';
                              }
                              return null;
                            },
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: _buildTextField(
                            controller: _priceController,
                            label: 'Price (\$) *',
                            hint: '0.00',
                            icon: Icons.attach_money,
                            keyboardType: const TextInputType.numberWithOptions(
                                decimal: true),
                            inputFormatters: [
                              FilteringTextInputFormatter.allow(
                                  RegExp(r'^\d+\.?\d{0,2}')),
                            ],
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Enter price';
                              }
                              if (double.tryParse(value) == null ||
                                  double.parse(value) <= 0) {
                                return 'Enter valid price';
                              }
                              return null;
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),

                    _buildExpiryDateSelector(),
                    const SizedBox(height: 24),

                    // Manufacturer Details
                    _buildSectionHeader('Manufacturer Details', Icons.business),
                    const SizedBox(height: 16),

                    _buildTextField(
                      controller: _manufacturerController,
                      label: 'Manufacturer',
                      hint: 'e.g., PharmaCorp Ltd.',
                      icon: Icons.business,
                    ),
                    const SizedBox(height: 16),

                    _buildTextField(
                      controller: _batchNumberController,
                      label: 'Batch Number',
                      hint: 'e.g., PCT2024001',
                      icon: Icons.qr_code,
                    ),
                    const SizedBox(height: 24),

                    // Additional Information
                    _buildSectionHeader('Additional Information', Icons.notes),
                    const SizedBox(height: 16),

                    _buildOTCSelector(),
                    const SizedBox(height: 16),

                    _buildTextField(
                      controller: _descriptionController,
                      label: 'Description',
                      hint: 'Brief description of the medicine and its uses...',
                      icon: Icons.description,
                      maxLines: 3,
                    ),
                    const SizedBox(height: 32),
                  ],
                ),
              ),
            ),

            // Bottom Action Buttons
            _buildBottomActions(),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Row(
      children: [
        Icon(
          icon,
          color: AppTheme.primaryTeal,
          size: 24,
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
                color: AppTheme.primaryTeal,
              ),
        ),
      ],
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    TextInputType? keyboardType,
    List<TextInputFormatter>? inputFormatters,
    String? Function(String?)? validator,
    int maxLines = 1,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      inputFormatters: inputFormatters,
      validator: validator,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Icon(icon, color: AppTheme.primaryTeal),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppTheme.primaryTeal, width: 2),
        ),
      ),
    );
  }

  Widget _buildFormDropdown() {
    return DropdownButtonFormField<String>(
      value: _selectedForm,
      decoration: InputDecoration(
        labelText: 'Form *',
        prefixIcon: const Icon(Icons.category, color: AppTheme.primaryTeal),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppTheme.primaryTeal, width: 2),
        ),
      ),
      items: _forms.map((form) {
        return DropdownMenuItem(
          value: form,
          child: Row(
            children: [
              Icon(
                _getFormIcon(form),
                size: 20,
                color: AppTheme.primaryTeal,
              ),
              const SizedBox(width: 8),
              Text(form),
            ],
          ),
        );
      }).toList(),
      onChanged: (value) {
        setState(() {
          _selectedForm = value!;
        });
      },
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please select a form';
        }
        return null;
      },
    );
  }

  Widget _buildExpiryDateSelector() {
    return InkWell(
      onTap: _selectExpiryDate,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey[400]!),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            const Icon(Icons.calendar_today, color: AppTheme.primaryTeal),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Expiry Date *',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Colors.grey[600],
                      ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${_selectedExpiryDate.day.toString().padLeft(2, '0')}/${_selectedExpiryDate.month.toString().padLeft(2, '0')}/${_selectedExpiryDate.year}',
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ],
            ),
            const Spacer(),
            const Icon(Icons.arrow_drop_down),
          ],
        ),
      ),
    );
  }

  Widget _buildOTCSelector() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Medicine Type',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: RadioListTile<bool>(
                  value: true,
                  groupValue: _isOTC,
                  onChanged: (value) {
                    setState(() {
                      _isOTC = value!;
                    });
                  },
                  title: const Row(
                    children: [
                      Icon(Icons.check_circle, color: AppTheme.successGreen),
                      SizedBox(width: 8),
                      Text('OTC'),
                    ],
                  ),
                  subtitle: const Text('Over the Counter'),
                  activeColor: AppTheme.primaryTeal,
                  contentPadding: EdgeInsets.zero,
                ),
              ),
              Expanded(
                child: RadioListTile<bool>(
                  value: false,
                  groupValue: _isOTC,
                  onChanged: (value) {
                    setState(() {
                      _isOTC = value!;
                    });
                  },
                  title: const Row(
                    children: [
                      Icon(Icons.warning, color: AppTheme.errorRed),
                      SizedBox(width: 8),
                      Text('Rx'),
                    ],
                  ),
                  subtitle: const Text('Prescription Required'),
                  activeColor: AppTheme.primaryTeal,
                  contentPadding: EdgeInsets.zero,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _saveMedicine() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      await _apiService.initialize();

      // Prepare medicine data for API
      final medicineData = {
        'name': _medicineNameController.text.trim(),
        'genericName': _genericNameController.text.trim(),
        'form': _selectedForm,
        'packSize': _packSizeController.text.trim(),
        'quantity': int.tryParse(_quantityController.text) ?? 0,
        'price': double.tryParse(_priceController.text) ?? 0.0,
        'expiryDate': _selectedExpiryDate.toIso8601String(),
        'manufacturer': _manufacturerController.text.trim(),
        'batchNumber': _batchNumberController.text.trim(),
        'description': _descriptionController.text.trim(),
        'isOTC': _isOTC,
        // category يمكن توليدها تلقائياً أو تركها فارغة إذا لم تكن مطلوبة
      };

      // Call API to add medicine
      await _apiService.addMedicine(medicineData);

      if (mounted) {
        // Show success message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                const Icon(Icons.check_circle, color: Colors.white),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Medicine "${_medicineNameController.text}" added successfully!',
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
            backgroundColor: AppTheme.successGreen,
            duration: const Duration(seconds: 3),
          ),
        );

        // Clear form and return success to trigger refresh in inventory
        _clearForm();
        Navigator.of(context).pop(true);
      }
    } catch (e) {
      if (mounted) {
        // Show error message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                const Icon(Icons.error, color: Colors.white),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Failed to add medicine: ${e.toString()}',
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
            backgroundColor: AppTheme.errorRed,
            duration: const Duration(seconds: 5),
            action: SnackBarAction(
              label: 'Retry',
              textColor: Colors.white,
              onPressed: _saveMedicine,
            ),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _clearForm() {
    _medicineNameController.clear();
    _genericNameController.clear();
    _packSizeController.clear();
    _quantityController.clear();
    _priceController.clear();
    _manufacturerController.clear();
    _batchNumberController.clear();
    _descriptionController.clear();
    setState(() {
      _selectedForm = 'Tablet';
      _selectedExpiryDate = DateTime.now().add(const Duration(days: 365));
      _isOTC = true;
    });
  }

  Widget _buildBottomActions() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border(
          top: BorderSide(color: Colors.grey[300]!),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton(
              onPressed: () => Navigator.of(context).pop(),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppTheme.primaryTeal,
                side: const BorderSide(color: AppTheme.primaryTeal),
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child: const Text('Cancel'),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            flex: 2,
            child: ElevatedButton(
              onPressed: _isLoading ? null : _saveMedicine,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryTeal,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child: _isLoading
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    )
                  : const Text(
                      'Add to Recyleto',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  IconData _getFormIcon(String form) {
    switch (form.toLowerCase()) {
      case 'tablet':
        return Icons.medication;
      case 'capsule':
        return Icons.medication_liquid;
      case 'syrup':
        return Icons.local_drink;
      case 'injection':
        return Icons.colorize;
      case 'cream':
        return Icons.healing;
      case 'ointment':
        return Icons.healing;
      case 'drops':
        return Icons.water_drop;
      case 'inhaler':
        return Icons.air;
      case 'patch':
        return Icons.medical_services;
      case 'powder':
        return Icons.scatter_plot;
      case 'gel':
        return Icons.bubble_chart;
      case 'lotion':
        return Icons.opacity;
      default:
        return Icons.medication;
    }
  }
}
