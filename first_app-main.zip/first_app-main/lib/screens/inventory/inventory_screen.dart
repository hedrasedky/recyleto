import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/auth_provider.dart';
import '../../services/api_service.dart';
import '../../utils/app_theme.dart';
import '../../widgets/custom_button.dart';
import 'add_medicine_screen.dart';

class InventoryScreen extends StatefulWidget {
  const InventoryScreen({super.key});

  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> {
  List<Map<String, dynamic>> _medicines = [];
  bool _loadingMedicines = true;
  String? _error;
  String? _currentSearch;
  String _currentFilter = 'all'; // all | low | expiring

  @override
  void initState() {
    super.initState();
    _checkAuthStatus();
    _fetchMedicines();
  }

  void _checkAuthStatus() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final authProvider = context.read<AuthProvider>();
      if (!authProvider.isAuthenticated) {
        Navigator.of(context).pushReplacementNamed('/login');
      }
    });
  }

  Future<void> _fetchMedicines() async {
    setState(() {
      _loadingMedicines = true;
      _error = null;
    });
    try {
      final api = ApiService();
      await api.initialize();
      List<Map<String, dynamic>> meds = [];
      if (_currentFilter == 'low') {
        meds = await api.getLowStockMedicines();
      } else if (_currentFilter == 'expiring') {
        meds = await api.getExpiringMedicines();
      } else {
        meds = await api.getMedicines(search: _currentSearch);
      }
      setState(() {
        _medicines = meds;
        _loadingMedicines = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loadingMedicines = false;
      });
    }
  }

  Future<void> _onAddMedicine() async {
    final result = await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => const AddMedicineScreen(),
      ),
    );
    if (result == true) {
      await _fetchMedicines();
    }
  }

  Future<void> _showSearchDialog() async {
    final controller = TextEditingController(text: _currentSearch ?? '');
    final value = await showDialog<String>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Search Medicines'),
          content: TextField(
            controller: controller,
            decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: 'Name, generic, form...'),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, controller.text.trim()),
              child: const Text('Search'),
            ),
          ],
        );
      },
    );
    if (value != null) {
      setState(() {
        _currentSearch = value.isEmpty ? null : value;
        _currentFilter = 'all';
      });
      await _fetchMedicines();
    }
  }

  Future<void> _showFilterDialog() async {
    final selected = await showDialog<String>(
      context: context,
      builder: (context) {
        return SimpleDialog(
          title: const Text('Filter'),
          children: [
            SimpleDialogOption(
              onPressed: () => Navigator.pop(context, 'all'),
              child: const Text('All'),
            ),
            SimpleDialogOption(
              onPressed: () => Navigator.pop(context, 'low'),
              child: const Text('Low stock'),
            ),
            SimpleDialogOption(
              onPressed: () => Navigator.pop(context, 'expiring'),
              child: const Text('Expiring soon'),
            ),
          ],
        );
      },
    );
    if (selected != null) {
      setState(() {
        _currentFilter = selected;
        if (selected != 'all') _currentSearch = null;
      });
      await _fetchMedicines();
    }
  }

  Future<void> _showEditBottomSheet(Map<String, dynamic> med) async {
    final id = med['_id'] ?? med['id'];
    if (id == null) return;
    final quantityController = TextEditingController(
        text: (med['stock'] ?? med['quantity'] ?? '').toString());
    final priceController =
        TextEditingController(text: (med['price'] ?? '').toString());
    await showModalBottomSheet(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 16,
            bottom: MediaQuery.of(context).viewInsets.bottom + 16,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                med['name'] ?? 'Medicine',
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: quantityController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Quantity',
                  prefixIcon: Icon(Icons.numbers),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: priceController,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: 'Price',
                  prefixIcon: Icon(Icons.attach_money),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        final api = ApiService();
                        await api.initialize();
                        final qty =
                            int.tryParse(quantityController.text.trim());
                        if (qty != null) {
                          // Use updateMedicine with stock field instead of updateMedicineStock
                          await api
                              .updateMedicine(id.toString(), {'stock': qty});
                        }
                        final price =
                            double.tryParse(priceController.text.trim());
                        if (price != null) {
                          await api
                              .updateMedicine(id.toString(), {'price': price});
                        }
                        if (mounted) {
                          Navigator.pop(context);
                          await _fetchMedicines();
                        }
                      },
                      icon: const Icon(Icons.save),
                      label: const Text('Save'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                          foregroundColor: Colors.white),
                      onPressed: () async {
                        final confirm = await showDialog<bool>(
                          context: context,
                          builder: (context) => AlertDialog(
                            title: const Text('Delete Medicine'),
                            content: const Text(
                                'Are you sure you want to delete this medicine?'),
                            actions: [
                              TextButton(
                                  onPressed: () =>
                                      Navigator.pop(context, false),
                                  child: const Text('Cancel')),
                              TextButton(
                                  onPressed: () => Navigator.pop(context, true),
                                  child: const Text('Delete')),
                            ],
                          ),
                        );
                        if (confirm == true) {
                          final api = ApiService();
                          await api.initialize();
                          await api.deleteMedicine(id.toString());
                          if (mounted) {
                            Navigator.pop(context);
                            await _fetchMedicines();
                          }
                        }
                      },
                      icon: const Icon(Icons.delete),
                      label: const Text('Delete'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Inventory'),
        actions: [
          IconButton(
            onPressed: _showSearchDialog,
            icon: const Icon(Icons.search),
          ),
          IconButton(
            onPressed: _showFilterDialog,
            icon: const Icon(Icons.filter_list),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.inventory_2,
                    size: 80,
                    color: AppTheme.primaryTeal.withOpacity(0.5),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    'Inventory Management',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'This screen will display all medicines in inventory\nwith stock levels, expiry dates, and management options.',
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          color: AppTheme.darkGray.withOpacity(0.7),
                        ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 32),
                  CustomButton(
                    onPressed: _onAddMedicine,
                    text: 'Add Medicine',
                    backgroundColor: AppTheme.primaryGreen,
                  ),
                ],
              ),
            ),
          ),
          const Divider(),
          Expanded(
            child: RefreshIndicator(
              onRefresh: _fetchMedicines,
              child: _loadingMedicines
                  ? ListView(children: const [
                      SizedBox(height: 300),
                      Center(child: CircularProgressIndicator())
                    ])
                  : _error != null
                      ? ListView(children: [
                          const SizedBox(height: 40),
                          Center(child: Text('Error: ${_error ?? ''}')),
                        ])
                      : _medicines.isEmpty
                          ? ListView(children: const [
                              SizedBox(height: 80),
                              Center(child: Text('No medicines found.')),
                            ])
                          : ListView.separated(
                              itemCount: _medicines.length,
                              separatorBuilder: (_, __) => const Divider(),
                              itemBuilder: (context, index) {
                                final med = _medicines[index];
                                return ListTile(
                                  onTap: () => _showEditBottomSheet(med),
                                  title: Text(med['name'] ?? ''),
                                  subtitle: Text(
                                      'Generic: ${med['genericName'] ?? ''}\nForm: ${med['form'] ?? ''}\nPack Size: ${med['packSize'] ?? ''}\nQuantity: ${med['stock'] ?? med['quantity'] ?? ''}\nPrice: ${med['price'] ?? ''}\nExpiry: ${med['expiryDate'] != null ? med['expiryDate'].toString().split('T')[0] : ''}'),
                                  isThreeLine: true,
                                  trailing: med['manufacturer'] != null &&
                                          med['manufacturer']
                                              .toString()
                                              .isNotEmpty
                                      ? Text(med['manufacturer'])
                                      : null,
                                );
                              },
                            ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _onAddMedicine,
        backgroundColor: AppTheme.primaryGreen,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text('Add Medicine'),
      ),
    );
  }
}
