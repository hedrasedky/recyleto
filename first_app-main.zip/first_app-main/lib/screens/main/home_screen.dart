import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/auth_provider.dart';
import '../../providers/dashboard_provider.dart';
import '../../providers/theme_provider.dart';
import '../../services/api_service.dart';
import '../../utils/app_routes.dart';
import '../../utils/app_theme.dart';
import '../../utils/dashboard_test.dart';
import '../../widgets/alert_card.dart';
import '../../widgets/kpi_card.dart';
import '../../widgets/quick_action_card.dart';
import '../../widgets/recent_activity_card.dart';
import '../inventory/add_medicine_screen.dart';
import '../inventory/inventory_screen.dart';
import '../profile/profile_screen.dart';
import '../sales/add_transaction_screen.dart';
import '../sales/sales_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _checkAuthStatus();
    _loadDashboardData();
  }

  void _checkAuthStatus() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final authProvider = context.read<AuthProvider>();
      if (!authProvider.isAuthenticated) {
        Navigator.of(context).pushReplacementNamed('/login');
      }
    });
  }

  void _loadDashboardData() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final dashboardProvider = context.read<DashboardProvider>();
      dashboardProvider.loadDashboardData();
    });
  }

  final List<Widget> _screens = [
    const HomeDashboard(),
    const SalesScreen(),
    const InventoryScreen(),
    const ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          type: BottomNavigationBarType.fixed,
          selectedItemColor: AppTheme.primaryTeal,
          unselectedItemColor: Colors.grey,
          backgroundColor: Theme.of(context).colorScheme.surface,
          elevation: 0,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined),
              activeIcon: Icon(Icons.home),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.point_of_sale_outlined),
              activeIcon: Icon(Icons.point_of_sale),
              label: 'Sales',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.inventory_2_outlined),
              activeIcon: Icon(Icons.inventory_2),
              label: 'Inventory',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_outline),
              activeIcon: Icon(Icons.person),
              label: 'Profile',
            ),
          ],
        ),
      ),
      floatingActionButton: _currentIndex == 0
          ? FloatingActionButton.extended(
              onPressed: () {
                AppRoutes.navigateTo(context, AppRoutes.requestMedicine);
              },
              backgroundColor: AppTheme.primaryTeal,
              foregroundColor: Colors.white,
              icon: const Icon(Icons.add),
              label: const Text('Add Request'),
            )
          : null,
    );
  }
}

class HomeDashboard extends StatefulWidget {
  const HomeDashboard({super.key});

  @override
  State<HomeDashboard> createState() => _HomeDashboardState();
}

class _HomeDashboardState extends State<HomeDashboard> {
  final ApiService _apiService = ApiService();

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final themeProvider = context.watch<ThemeProvider>();
    final dashboardProvider = context.watch<DashboardProvider>();

    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: RefreshIndicator(
        onRefresh: () => dashboardProvider.refresh(),
        child: SafeArea(
          child: CustomScrollView(
            slivers: [
              // App Bar
              SliverAppBar(
                expandedHeight: 120,
                floating: false,
                pinned: true,
                backgroundColor: Theme.of(context).colorScheme.surface,
                elevation: 0,
                flexibleSpace: FlexibleSpaceBar(
                  titlePadding: const EdgeInsets.only(left: 16, bottom: 16),
                  title: Container(
                    constraints: const BoxConstraints(maxHeight: 60),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'Welcome back!',
                          style:
                              Theme.of(context).textTheme.titleSmall?.copyWith(
                                    color: AppTheme.darkGray.withOpacity(0.7),
                                  ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Flexible(
                          child: Text(
                            authProvider.pharmacyName ?? 'Pharmacy',
                            style: Theme.of(context)
                                .textTheme
                                .headlineSmall
                                ?.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: AppTheme.primaryTeal,
                                ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                actions: [
                  IconButton(
                    onPressed: () {
                      themeProvider.toggleTheme();
                    },
                    icon: Icon(
                      themeProvider.themeMode == ThemeMode.dark
                          ? Icons.light_mode
                          : Icons.dark_mode,
                      color: AppTheme.primaryTeal,
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      _showNotificationsDialog();
                    },
                    icon: Stack(
                      children: [
                        const Icon(
                          Icons.notifications_outlined,
                          color: AppTheme.primaryTeal,
                        ),
                        if (dashboardProvider.unreadNotificationsCount > 0)
                          Positioned(
                            right: 0,
                            top: 0,
                            child: Container(
                              width: 16,
                              height: 16,
                              decoration: const BoxDecoration(
                                color: AppTheme.errorRed,
                                shape: BoxShape.circle,
                              ),
                              child: Center(
                                child: Text(
                                  '${dashboardProvider.unreadNotificationsCount}',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                ],
              ),

              // Content
              SliverPadding(
                padding: const EdgeInsets.all(16.0),
                sliver: SliverList(
                  delegate: SliverChildListDelegate([
                    // KPI Cards
                    Text(
                      'Today\'s Overview',
                      style:
                          Theme.of(context).textTheme.headlineSmall?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                    ),
                    const SizedBox(height: 16),

                    // KPI Cards with Real-time Data
                    if (dashboardProvider.isLoadingStatistics)
                      const Center(child: CircularProgressIndicator())
                    else if (dashboardProvider.statisticsError != null)
                      _buildErrorCard('Failed to load statistics',
                          dashboardProvider.statisticsError!)
                    else if (dashboardProvider.statistics != null)
                      _buildKPICards(dashboardProvider.statistics!)
                    else
                      _buildLoadingKPICards(),

                    const SizedBox(height: 16),

                    // Debug Test Button (remove in production)
                    OutlinedButton.icon(
                      onPressed: () async {
                        print('🧪 Starting dashboard test...');
                        await DashboardTest.testDashboardEndpoints();
                      },
                      icon: const Icon(Icons.bug_report),
                      label: const Text('Test Dashboard API'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.orange,
                        side: const BorderSide(color: Colors.orange),
                      ),
                    ),

                    const SizedBox(height: 32),

                    // Quick Actions
                    Text(
                      'Quick Actions',
                      style:
                          Theme.of(context).textTheme.headlineSmall?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                    ),
                    const SizedBox(height: 16),

                    _buildQuickActions(context),

                    const SizedBox(height: 32),

                    // Alerts Section with Real-time Data
                    Text(
                      'Alerts & Notifications',
                      style:
                          Theme.of(context).textTheme.headlineSmall?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                    ),
                    const SizedBox(height: 16),

                    if (dashboardProvider.isLoadingAlerts)
                      const Center(child: CircularProgressIndicator())
                    else if (dashboardProvider.alertsError != null)
                      _buildErrorCard('Failed to load alerts',
                          dashboardProvider.alertsError!)
                    else if (dashboardProvider.alerts.isNotEmpty)
                      _buildAlertsList(
                          dashboardProvider.alerts, dashboardProvider)
                    else
                      _buildNoAlertsCard(),

                    const SizedBox(height: 32),

                    // Recent Activity with Real-time Data
                    Text(
                      'Recent Activity',
                      style:
                          Theme.of(context).textTheme.headlineSmall?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                    ),
                    const SizedBox(height: 16),

                    if (dashboardProvider.isLoadingActivities)
                      const Center(child: CircularProgressIndicator())
                    else if (dashboardProvider.activitiesError != null)
                      _buildErrorCard('Failed to load activities',
                          dashboardProvider.activitiesError!)
                    else if (dashboardProvider.recentActivities.isNotEmpty)
                      _buildRecentActivitiesList(
                          dashboardProvider.recentActivities)
                    else
                      _buildNoActivitiesCard(),

                    const SizedBox(height: 100), // Bottom padding for FAB
                  ]),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildKPICards(Map<String, dynamic> statistics) {
    // Use the actual data structure from backend
    final totalSales = statistics['totalSales'] ?? 0;
    final lowStockCount = statistics['lowStockCount'] ?? 0;
    final expiringCount = statistics['expiringCount'] ?? 0;
    final pendingRequests = statistics['pendingRequestsCount'] ?? 0;

    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      childAspectRatio: 1.2,
      children: [
        KPICard(
          title: 'Total Sales',
          value: '\$${totalSales.toStringAsFixed(2)}',
          change: 'Today',
          isPositive: true,
          icon: Icons.trending_up,
          color: AppTheme.successGreen,
        ),
        KPICard(
          title: 'Low Stock',
          value: '$lowStockCount',
          change: 'Items',
          isPositive: false,
          icon: Icons.warning,
          color: AppTheme.warningOrange,
        ),
        KPICard(
          title: 'Expiring Soon',
          value: '$expiringCount',
          change: 'Items',
          isPositive: false,
          icon: Icons.schedule,
          color: AppTheme.errorRed,
        ),
        KPICard(
          title: 'Pending Requests',
          value: '$pendingRequests',
          change: 'Items',
          isPositive: false,
          icon: Icons.assignment_return,
          color: AppTheme.primaryTeal,
        ),
      ],
    );
  }

  Widget _buildLoadingKPICards() {
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      childAspectRatio: 1.2,
      children: List.generate(
          4,
          (index) => const Card(
                child: Center(child: CircularProgressIndicator()),
              )),
    );
  }

  Widget _buildQuickActions(BuildContext context) {
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      childAspectRatio: 1.5,
      children: [
        QuickActionCard(
          title: 'New Sale',
          subtitle: 'Process transaction',
          icon: Icons.add_shopping_cart,
          color: AppTheme.primaryTeal,
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const AddTransactionScreen(),
              ),
            );
          },
        ),
        QuickActionCard(
          title: 'Add Medicine',
          subtitle: 'To inventory',
          icon: Icons.medication,
          color: AppTheme.primaryGreen,
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const AddMedicineScreen(),
              ),
            );
          },
        ),
        QuickActionCard(
          title: 'View Sales',
          subtitle: 'Transaction history',
          icon: Icons.receipt_long,
          color: AppTheme.darkTeal,
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const SalesScreen(),
              ),
            );
          },
        ),
        QuickActionCard(
          title: 'Inventory',
          subtitle: 'Manage stock',
          icon: Icons.inventory_2,
          color: AppTheme.lightTeal,
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const InventoryScreen(),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildAlertsList(
      List<Map<String, dynamic>> alerts, DashboardProvider dashboardProvider) {
    return Column(
      children: alerts.map((alert) {
        final priority = alert['priority'] ?? 'medium';
        final type = alert['type'] ?? 'info';

        Color alertColor;
        IconData alertIcon;

        switch (priority) {
          case 'critical':
            alertColor = AppTheme.errorRed;
            alertIcon = Icons.error;
            break;
          case 'high':
            alertColor = AppTheme.warningOrange;
            alertIcon = Icons.warning;
            break;
          default:
            alertColor = AppTheme.primaryTeal;
            alertIcon = Icons.info;
        }

        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: AlertCard(
            title: alert['title'] ?? 'Alert',
            message: alert['message'] ?? 'No message',
            type: _getAlertType(type),
            icon: alertIcon,
          ),
        );
      }).toList(),
    );
  }

  Widget _buildNoAlertsCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Center(
          child: Column(
            children: [
              Icon(
                Icons.check_circle_outline,
                size: 48,
                color: AppTheme.successGreen.withOpacity(0.7),
              ),
              const SizedBox(height: 8),
              const Text(
                'All Good!',
                style: TextStyle(
                  color: AppTheme.successGreen,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'No alerts at the moment',
                style: TextStyle(
                  color: AppTheme.darkGray.withOpacity(0.7),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRecentActivitiesList(List<Map<String, dynamic>> activities) {
    return Column(
      children: activities.map((activity) {
        final type = activity['type'] ?? 'info';
        final amount = activity['amount'];
        final timeAgo = activity['timeAgo'] ?? 'Unknown time';

        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: RecentActivityCard(
            title: activity['title'] ?? 'Activity',
            subtitle: activity['subtitle'] ?? 'No details',
            amount: amount?.toString() ?? '',
            time: timeAgo,
            type: _getActivityType(type),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildNoActivitiesCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Center(
          child: Column(
            children: [
              Icon(
                Icons.history,
                size: 48,
                color: AppTheme.darkGray.withOpacity(0.5),
              ),
              const SizedBox(height: 8),
              Text(
                'No Recent Activity',
                style: TextStyle(
                  color: AppTheme.darkGray.withOpacity(0.7),
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildErrorCard(String title, String message) {
    return Card(
      color: AppTheme.errorRed.withOpacity(0.1),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Icon(
              Icons.error_outline,
              color: AppTheme.errorRed,
              size: 32,
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: const TextStyle(
                color: AppTheme.errorRed,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              message,
              style: TextStyle(
                color: AppTheme.errorRed.withOpacity(0.8),
                fontSize: 12,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  AlertType _getAlertType(String type) {
    switch (type) {
      case 'low_stock':
        return AlertType.warning;
      case 'expiry':
        return AlertType.error;
      default:
        return AlertType.info;
    }
  }

  ActivityType _getActivityType(String type) {
    switch (type) {
      case 'sale':
        return ActivityType.sale;
      case 'inventory':
        return ActivityType.inventory;
      case 'refund':
        return ActivityType.refund;
      default:
        return ActivityType.request;
    }
  }

  void _showNotificationsDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Notifications'),
        content: SizedBox(
          width: double.maxFinite,
          child: FutureBuilder<Map<String, dynamic>>(
            future: _apiService.getNotifications(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }

              if (snapshot.hasError) {
                return Center(
                  child: Text('Error: ${snapshot.error}'),
                );
              }

              final data = snapshot.data;
              final notifications = data?['notifications'] ?? [];
              final unreadCount = data?['unreadCount'] ?? 0;

              if (notifications.isEmpty) {
                return const Center(
                  child: Text('No notifications'),
                );
              }

              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (unreadCount > 0)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: Text(
                        '$unreadCount unread notification${unreadCount > 1 ? 's' : ''}',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: AppTheme.primaryTeal,
                        ),
                      ),
                    ),
                  ...notifications.map((notification) => ListTile(
                        leading: Icon(
                          notification['type'] == 'system'
                              ? Icons.system_update
                              : Icons.notifications,
                          color: AppTheme.primaryTeal,
                        ),
                        title: Text(notification['title'] ?? 'Notification'),
                        subtitle: Text(notification['message'] ?? ''),
                        trailing: notification['isRead'] == false
                            ? Container(
                                width: 8,
                                height: 8,
                                decoration: const BoxDecoration(
                                  color: AppTheme.errorRed,
                                  shape: BoxShape.circle,
                                ),
                              )
                            : null,
                      )),
                ],
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}
