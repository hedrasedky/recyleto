import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../services/api_service.dart';
import '../../services/payment_service.dart';
import '../../utils/app_theme.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _formKey = GlobalKey<FormState>();
  final _customerNameController = TextEditingController();
  final _customerPhoneController = TextEditingController();
  final _customerEmailController = TextEditingController();
  final _notesController = TextEditingController();
  final ApiService _apiService = ApiService();
  final PaymentService _paymentService = PaymentService();

  String _selectedPaymentMethod = 'cash';
  bool _printReceipt = true;
  bool _emailReceipt = false;
  bool _smsReceipt = false;
  bool _isProcessing = false;
  bool _isLoading = true;
  String? _error;

  List<Map<String, dynamic>> _cartItems = [];
  List<PaymentMethod> _availablePaymentMethods = [];

  @override
  void initState() {
    super.initState();
    _loadCartItems();
    _loadPaymentMethods();
  }

  Future<void> _loadCartItems() async {
    try {
      setState(() {
        _isLoading = true;
        _error = null;
      });

      await _apiService.initialize();
      final items = await _apiService.getCartItems();

      setState(() {
        _cartItems = items;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isLoading = false;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to load cart: ${e.toString()}'),
            backgroundColor: AppTheme.errorRed,
            action: SnackBarAction(
              label: 'Retry',
              textColor: Colors.white,
              onPressed: _loadCartItems,
            ),
          ),
        );
      }
    }
  }

  Future<void> _loadPaymentMethods() async {
    try {
      await _paymentService.initialize();
      final methods = _paymentService.getAvailablePaymentMethods();
      setState(() {
        _availablePaymentMethods = methods;
      });
    } catch (e) {
      debugPrint('Failed to load payment methods: $e');
    }
  }

  double get _subtotal => _cartItems.fold(0,
      (sum, item) => sum + ((item['price'] ?? 0.0) * (item['quantity'] ?? 1)));
  double get _discountAmount => _cartItems.fold(
      0,
      (sum, item) =>
          sum +
          (((item['originalPrice'] ?? item['price'] ?? 0.0) -
                  (item['price'] ?? 0.0)) *
              (item['quantity'] ?? 1)));
  double get _tax => _subtotal * 0.05; // 5% tax
  double get _total => _subtotal + _tax;

  String _generateTransactionReference() {
    final now = DateTime.now();
    return 'TX-${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}-${now.millisecondsSinceEpoch.toString().substring(8)}';
  }

  @override
  void dispose() {
    _customerNameController.dispose();
    _customerPhoneController.dispose();
    _customerEmailController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _processPayment() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isProcessing = true;
      _error = null;
    });

    try {
      PaymentResult result;

      switch (_selectedPaymentMethod) {
        case 'stripe_card':
          result = await _paymentService.processStripePayment(
            amount: _total,
            currency: 'USD',
            customerEmail: _customerEmailController.text,
            customerName: _customerNameController.text,
          );
          break;

        case 'paypal':
          result = await _paymentService.processPayPalPayment(
            amount: _total,
            currency: 'USD',
            customerEmail: _customerEmailController.text,
          );
          break;

        case 'razorpay':
          result = await _paymentService.processRazorpayPayment(
            amount: _total,
            currency: 'INR',
            customerEmail: _customerEmailController.text,
            customerName: _customerNameController.text,
            customerPhone: _customerPhoneController.text,
          );
          break;

        case 'flutterwave':
          result = await _paymentService.processFlutterwavePayment(
            amount: _total,
            currency: 'NGN',
            customerEmail: _customerEmailController.text,
            customerName: _customerNameController.text,
            customerPhone: _customerPhoneController.text,
            transactionReference: _generateTransactionReference(),
          );
          break;

        case 'cash':
        case 'bank_transfer':
          // For cash and bank transfer, we'll simulate success
          result = PaymentResult(
            success: true,
            transactionId: _generateTransactionReference(),
            message:
                'Payment method selected: ${_getPaymentMethodName(_selectedPaymentMethod)}',
            paymentMethod: _selectedPaymentMethod,
          );
          break;

        default:
          result = PaymentResult(
            success: false,
            message: 'Unsupported payment method',
            paymentMethod: _selectedPaymentMethod,
          );
      }

      if (result.success) {
        // Process checkout with API
        await _apiService.processCheckout({
          'items': _cartItems
              .map((item) => {
                    'medicineId': item['medicineId'],
                    'quantity': item['quantity'],
                    'price': item['price'],
                  })
              .toList(),
          'totalAmount': _total,
          'paymentMethod': _selectedPaymentMethod,
          'customerName': _customerNameController.text,
          'customerPhone': _customerPhoneController.text,
          'customerEmail': _customerEmailController.text,
          'notes': _notesController.text,
          'transactionReference': result.transactionId,
        });

        // Clear cart
        await _apiService.clearCart();

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                  'Payment successful! Transaction ID: ${result.transactionId}'),
              backgroundColor: AppTheme.successGreen,
            ),
          );

          // Navigate back to market
          Navigator.of(context).pop();
        }
      } else {
        setState(() {
          _error = result.message;
        });

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Payment failed: ${result.message}'),
              backgroundColor: AppTheme.errorRed,
            ),
          );
        }
      }
    } catch (e) {
      setState(() {
        _error = e.toString();
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Payment error: ${e.toString()}'),
            backgroundColor: AppTheme.errorRed,
          ),
        );
      }
    } finally {
      setState(() {
        _isProcessing = false;
      });
    }
  }

  String _getPaymentMethodName(String methodId) {
    final method = _availablePaymentMethods.firstWhere(
      (method) => method.id == methodId,
      orElse: () => PaymentMethod(
        id: methodId,
        name: methodId.toUpperCase(),
        icon: '💳',
        description: '',
        isAvailable: true,
      ),
    );
    return method.name;
  }

  Widget _buildPaymentMethodSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Payment Method',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                color: AppTheme.darkGray,
                fontWeight: FontWeight.w600,
              ),
        ),
        const SizedBox(height: 12),
        Container(
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: _availablePaymentMethods.map((method) {
              return RadioListTile<String>(
                value: method.id,
                groupValue: _selectedPaymentMethod,
                onChanged: (newValue) {
                  setState(() {
                    _selectedPaymentMethod = newValue!;
                  });
                },
                title: Row(
                  children: [
                    Text(
                      method.icon,
                      style: const TextStyle(fontSize: 24),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            method.name,
                            style: Theme.of(context)
                                .textTheme
                                .titleMedium
                                ?.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                          if (method.description.isNotEmpty)
                            Text(
                              method.description,
                              style: Theme.of(context)
                                  .textTheme
                                  .bodySmall
                                  ?.copyWith(
                                    color: Colors.grey.shade600,
                                  ),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
                activeColor: _selectedPaymentMethod == method.id
                    ? AppTheme.primaryTeal
                    : Colors.grey,
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final transactionRef = _generateTransactionReference();

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        title: const Text(
          'Checkout',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: AppTheme.primaryTeal,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Error: $_error'),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _loadCartItems,
                        child: const Text('Retry'),
                      ),
                    ],
                  ),
                )
              : _cartItems.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.shopping_cart_outlined,
                            size: 80,
                            color: theme.colorScheme.onSurface.withOpacity(0.3),
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Your cart is empty',
                            style: theme.textTheme.headlineSmall?.copyWith(
                              color:
                                  theme.colorScheme.onSurface.withOpacity(0.7),
                            ),
                          ),
                          const SizedBox(height: 24),
                          ElevatedButton(
                            onPressed: () => Navigator.of(context).pop(),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.primaryGreen,
                              foregroundColor: Colors.white,
                            ),
                            child: const Text('Back to Cart'),
                          ),
                        ],
                      ),
                    )
                  : Form(
                      key: _formKey,
                      child: Column(
                        children: [
                          Expanded(
                            child: RefreshIndicator(
                              onRefresh: _loadCartItems,
                              child: SingleChildScrollView(
                                padding: const EdgeInsets.all(16),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    // Transaction Summary
                                    _buildTransactionSummary(
                                        theme, transactionRef),
                                    const SizedBox(height: 24),

                                    // Order Details
                                    _buildOrderDetails(theme),
                                    const SizedBox(height: 24),

                                    // Customer Information
                                    _buildCustomerInformation(theme),
                                    const SizedBox(height: 24),

                                    // Payment Method Selection
                                    _buildPaymentMethodSelector(),
                                    const SizedBox(height: 24),

                                    // Receipt Options
                                    _buildReceiptOptions(theme),
                                    const SizedBox(height: 24),

                                    // Transaction Notes
                                    _buildTransactionNotes(theme),
                                    const SizedBox(height: 100),
                                  ],
                                ),
                              ),
                            ),
                          ),

                          // Bottom Summary and Checkout Button
                          _buildBottomCheckout(theme),
                        ],
                      ),
                    ),
    );
  }

  Widget _buildTransactionSummary(ThemeData theme, String transactionRef) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.primaryTeal.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.primaryTeal.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.receipt_long,
                color: AppTheme.primaryTeal,
                size: 24,
              ),
              const SizedBox(width: 8),
              Text(
                'Transaction Summary',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryTeal,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Text(
                'Reference Number:',
                style: theme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w500,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  transactionRef,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    fontFamily: 'monospace',
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Text(
                'Date & Time:',
                style: theme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w500,
                ),
              ),
              const Spacer(),
              Text(
                DateTime.now().toString().substring(0, 16),
                style: theme.textTheme.bodyMedium,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildOrderDetails(ThemeData theme) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Order Details',
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),

          // Medicine breakdown
          ...(_cartItems
              .map((item) => _buildMedicineBreakdown(item, theme))
              .toList()),

          const Divider(height: 24),

          // Pricing summary
          _buildPricingSummary(theme),
        ],
      ),
    );
  }

  Widget _buildMedicineBreakdown(Map<String, dynamic> item, ThemeData theme) {
    final itemTotal = (item['price'] ?? 0.0) * (item['quantity'] ?? 1);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item['name'] ?? 'N/A',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      '${item['genericName']} • ${item['form']}',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: Colors.grey[600],
                      ),
                    ),
                    Text(
                      '${item['manufacturer']} • ${item['packSize']}',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    'Qty: ${item['quantity'] ?? 1}',
                    style: theme.textTheme.bodySmall?.copyWith(
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    '\$${(item['price'] ?? 0.0).toStringAsFixed(2)} each',
                    style: theme.textTheme.bodySmall,
                  ),
                  Text(
                    '\$${itemTotal.toStringAsFixed(2)}',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryTeal,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              Text(
                'Batch: ${item['batchNumber']}',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: Colors.grey[500],
                ),
              ),
              const Spacer(),
              Text(
                'Exp: ${item['expiryDate']?.substring(0, 10) ?? 'N/A'}',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: Colors.grey[500],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildPricingSummary(ThemeData theme) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Subtotal:', style: theme.textTheme.bodyMedium),
            Text('\$${_subtotal.toStringAsFixed(2)}',
                style: theme.textTheme.bodyMedium),
          ],
        ),
        if (_discountAmount > 0) ...[
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Discount:',
                  style: theme.textTheme.bodyMedium
                      ?.copyWith(color: AppTheme.successGreen)),
              Text('-\$${_discountAmount.toStringAsFixed(2)}',
                  style: theme.textTheme.bodyMedium
                      ?.copyWith(color: AppTheme.successGreen)),
            ],
          ),
        ],
        const SizedBox(height: 4),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Tax (5%):', style: theme.textTheme.bodyMedium),
            Text('\$${_tax.toStringAsFixed(2)}',
                style: theme.textTheme.bodyMedium),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Total:',
              style: theme.textTheme.titleMedium
                  ?.copyWith(fontWeight: FontWeight.bold),
            ),
            Text(
              '\$${_total.toStringAsFixed(2)}',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: AppTheme.primaryTeal,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildCustomerInformation(ThemeData theme) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Customer Information (Optional)',
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _customerNameController,
            decoration: const InputDecoration(
              labelText: 'Customer Name',
              hintText: 'Enter customer name',
              prefixIcon: Icon(Icons.person_outline),
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _customerPhoneController,
            keyboardType: TextInputType.phone,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            decoration: const InputDecoration(
              labelText: 'Phone Number',
              hintText: 'Enter phone number',
              prefixIcon: Icon(Icons.phone_outlined),
              border: OutlineInputBorder(),
            ),
            validator: (value) {
              if (value != null && value.isNotEmpty && value.length < 10) {
                return 'Please enter a valid phone number';
              }
              return null;
            },
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _customerEmailController,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(
              labelText: 'Email Address (Optional)',
              hintText: 'Enter email address',
              prefixIcon: Icon(Icons.email_outlined),
              border: OutlineInputBorder(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReceiptOptions(ThemeData theme) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Receipt Options',
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          CheckboxListTile(
            value: _printReceipt,
            onChanged: (value) {
              setState(() {
                _printReceipt = value ?? false;
              });
            },
            title: const Row(
              children: [
                Icon(Icons.print),
                SizedBox(width: 12),
                Text('Print Receipt'),
              ],
            ),
            activeColor: AppTheme.primaryTeal,
            contentPadding: EdgeInsets.zero,
          ),
          CheckboxListTile(
            value: _emailReceipt,
            onChanged: (value) {
              setState(() {
                _emailReceipt = value ?? false;
              });
            },
            title: const Row(
              children: [
                Icon(Icons.email),
                SizedBox(width: 12),
                Text('Email Receipt'),
              ],
            ),
            activeColor: AppTheme.primaryTeal,
            contentPadding: EdgeInsets.zero,
          ),
          CheckboxListTile(
            value: _smsReceipt,
            onChanged: (value) {
              setState(() {
                _smsReceipt = value ?? false;
              });
            },
            title: const Row(
              children: [
                Icon(Icons.sms),
                SizedBox(width: 12),
                Text('SMS Receipt'),
              ],
            ),
            activeColor: AppTheme.primaryTeal,
            contentPadding: EdgeInsets.zero,
          ),
        ],
      ),
    );
  }

  Widget _buildTransactionNotes(ThemeData theme) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Transaction Notes (Optional)',
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _notesController,
            maxLines: 3,
            decoration: const InputDecoration(
              hintText: 'Add special instructions or notes...',
              border: OutlineInputBorder(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomCheckout(ThemeData theme) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        border: Border(
          top: BorderSide(color: Colors.grey[300]!),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Total Amount:',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                '\$${_total.toStringAsFixed(2)}',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryTeal,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.of(context).pop(),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppTheme.primaryTeal,
                    side: const BorderSide(color: AppTheme.primaryTeal),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                  child: const Text('Back to Cart'),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                flex: 2,
                child: ElevatedButton(
                  onPressed: _isProcessing ? null : _processPayment,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryTeal,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                  child: _isProcessing
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor:
                                AlwaysStoppedAnimation<Color>(Colors.white),
                          ),
                        )
                      : const Text(
                          'Confirm Payment',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
