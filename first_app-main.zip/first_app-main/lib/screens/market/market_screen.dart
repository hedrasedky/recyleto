import 'package:flutter/material.dart';

import '../../services/api_service.dart';
import '../../utils/app_routes.dart';
import '../../utils/app_theme.dart';

class MarketScreen extends StatefulWidget {
  const MarketScreen({super.key});

  @override
  State<MarketScreen> createState() => _MarketScreenState();
}

class _MarketScreenState extends State<MarketScreen> {
  final _searchController = TextEditingController();
  final ApiService _apiService = ApiService();

  String _selectedCategory = 'All';
  String _searchQuery = '';
  int _cartItemCount = 0;
  bool _isLoading = true;
  String? _errorMessage;

  final List<String> _categories = [
    'All',
    'Pain Relief',
    'Antibiotics',
    'Vitamins',
    'Cold & Flu',
    'Heart',
    'Diabetes',
    'Gastrointestinal',
    'Allergy'
  ];

  List<Map<String, dynamic>> _medicines = [];

  @override
  void initState() {
    super.initState();
    _loadMedicines();
  }

  Future<void> _loadMedicines() async {
    try {
      setState(() {
        _isLoading = true;
        _errorMessage = null;
      });

      await _apiService.initialize();
      final medicines = await _apiService.getMedicines();

      setState(() {
        _medicines = medicines.map((medicine) {
          // Transform backend data to match UI expectations
          return {
            'id': medicine['_id'] ?? medicine['id'],
            'name': medicine['name'] ?? 'Unknown Medicine',
            'category': medicine['category'] ?? 'Other',
            'price': (medicine['price'] ?? 0.0).toDouble(),
            'originalPrice':
                (medicine['originalPrice'] ?? medicine['price'] ?? 0.0)
                    .toDouble(),
            'description':
                medicine['description'] ?? 'No description available',
            'stock': medicine['stock'] ?? 0,
            'rating': (medicine['rating'] ?? 4.0).toDouble(),
            'reviews': medicine['reviews'] ?? 0,
            'manufacturer': medicine['manufacturer'] ?? 'Unknown',
            'isOTC': medicine['isOTC'] ?? true,
            'discount': medicine['discount'] ?? 0,
            'genericName': medicine['genericName'],
            'batchNumber': medicine['batchNumber'],
            'expiryDate': medicine['expiryDate'],
            'form': medicine['form'],
            'packSize': medicine['packSize'],
          };
        }).toList();
        _isLoading = false;
      });

      // Update cart count
      await _updateCartCount();
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Failed to load medicines: ${e.toString()}';
      });

      // Show error to user
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to load medicines: ${e.toString()}'),
            backgroundColor: Colors.red,
            action: SnackBarAction(
              label: 'Retry',
              textColor: Colors.white,
              onPressed: _loadMedicines,
            ),
          ),
        );
      }
    }
  }

  Future<void> _searchMedicines(String query) async {
    try {
      setState(() {
        _isLoading = true;
        _errorMessage = null;
      });

      final medicines = await _apiService.getMedicines(search: query);

      setState(() {
        _medicines = medicines.map((medicine) {
          return {
            'id': medicine['_id'] ?? medicine['id'],
            'name': medicine['name'] ?? 'Unknown Medicine',
            'category': medicine['category'] ?? 'Other',
            'price': (medicine['price'] ?? 0.0).toDouble(),
            'originalPrice':
                (medicine['originalPrice'] ?? medicine['price'] ?? 0.0)
                    .toDouble(),
            'description':
                medicine['description'] ?? 'No description available',
            'stock': medicine['stock'] ?? 0,
            'rating': (medicine['rating'] ?? 4.0).toDouble(),
            'reviews': medicine['reviews'] ?? 0,
            'manufacturer': medicine['manufacturer'] ?? 'Unknown',
            'isOTC': medicine['isOTC'] ?? true,
            'discount': medicine['discount'] ?? 0,
            'genericName': medicine['genericName'],
            'batchNumber': medicine['batchNumber'],
            'expiryDate': medicine['expiryDate'],
          };
        }).toList();
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Search failed: ${e.toString()}';
      });
    }
  }

  List<Map<String, dynamic>> get _filteredMedicines {
    List<Map<String, dynamic>> filtered = _medicines;

    // Filter by category
    if (_selectedCategory != 'All') {
      filtered = filtered
          .where((medicine) => medicine['category'] == _selectedCategory)
          .toList();
    }

    // Filter by search query
    if (_searchQuery.isNotEmpty) {
      filtered = filtered
          .where((medicine) =>
              medicine['name']
                  .toLowerCase()
                  .contains(_searchQuery.toLowerCase()) ||
              medicine['description']
                  .toLowerCase()
                  .contains(_searchQuery.toLowerCase()) ||
              medicine['manufacturer']
                  .toLowerCase()
                  .contains(_searchQuery.toLowerCase()))
          .toList();
    }

    return filtered;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        title: const Text(
          'Medicine Market',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: AppTheme.primaryTeal,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          Stack(
            children: [
              IconButton(
                icon: const Icon(Icons.shopping_cart_outlined),
                onPressed: () {
                  AppRoutes.navigateTo(context, AppRoutes.cart);
                },
              ),
              if (_cartItemCount > 0)
                Positioned(
                  right: 8,
                  top: 8,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: AppTheme.errorRed,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    constraints: const BoxConstraints(
                      minWidth: 16,
                      minHeight: 16,
                    ),
                    child: Text(
                      '$_cartItemCount',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () {
              _showFilterDialog();
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(
                    color: AppTheme.primaryTeal,
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Loading medicines...',
                    style: TextStyle(
                      color: AppTheme.darkGray,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            )
          : _errorMessage != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.error_outline,
                        size: 64,
                        color: AppTheme.errorRed,
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'Failed to load medicines',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: AppTheme.darkGray,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 32),
                        child: Text(
                          _errorMessage!,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: AppTheme.darkGray.withOpacity(0.7),
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      ElevatedButton.icon(
                        onPressed: _loadMedicines,
                        icon: const Icon(Icons.refresh),
                        label: const Text('Retry'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.primaryTeal,
                          foregroundColor: Colors.white,
                        ),
                      ),
                    ],
                  ),
                )
              : Column(
                  children: [
                    // Search Bar
                    Container(
                      color: AppTheme.primaryTeal,
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                      child: TextField(
                        controller: _searchController,
                        onChanged: (value) {
                          setState(() {
                            _searchQuery = value;
                          });
                          // Debounce search to avoid too many API calls
                          if (value.isEmpty) {
                            _loadMedicines();
                          } else {
                            _searchMedicines(value);
                          }
                        },
                        decoration: InputDecoration(
                          hintText: 'Search medicines, brands, or symptoms...',
                          prefixIcon: const Icon(Icons.search),
                          suffixIcon: _searchQuery.isNotEmpty
                              ? IconButton(
                                  icon: const Icon(Icons.clear),
                                  onPressed: () {
                                    _searchController.clear();
                                    setState(() {
                                      _searchQuery = '';
                                    });
                                    _loadMedicines(); // Reload all medicines
                                  },
                                )
                              : null,
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 12,
                          ),
                        ),
                      ),
                    ),

                    // Categories
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      child: SizedBox(
                        height: 45,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          itemCount: _categories.length,
                          itemBuilder: (context, index) {
                            final category = _categories[index];
                            final isSelected = category == _selectedCategory;

                            return Padding(
                              padding: const EdgeInsets.only(right: 12),
                              child: GestureDetector(
                                onTap: () {
                                  setState(() {
                                    _selectedCategory = category;
                                  });
                                },
                                child: AnimatedContainer(
                                  duration: const Duration(milliseconds: 200),
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 20,
                                    vertical: 10,
                                  ),
                                  decoration: BoxDecoration(
                                    color: isSelected
                                        ? AppTheme.primaryTeal
                                        : Colors.grey[100],
                                    borderRadius: BorderRadius.circular(25),
                                    border: Border.all(
                                      color: isSelected
                                          ? AppTheme.primaryTeal
                                          : Colors.grey[300]!,
                                      width: 1,
                                    ),
                                  ),
                                  child: Center(
                                    child: Text(
                                      category,
                                      style: TextStyle(
                                        color: isSelected
                                            ? Colors.white
                                            : Colors.grey[700],
                                        fontWeight: isSelected
                                            ? FontWeight.bold
                                            : FontWeight.w500,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ),

                    // Results Count
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Row(
                        children: [
                          Text(
                            '${_filteredMedicines.length} medicines found',
                            style: theme.textTheme.bodyMedium?.copyWith(
                              color: Colors.grey[600],
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const Spacer(),
                          IconButton(
                            icon: const Icon(Icons.view_module),
                            onPressed: () {},
                            iconSize: 20,
                          ),
                          IconButton(
                            icon: const Icon(Icons.view_list),
                            onPressed: () {},
                            iconSize: 20,
                          ),
                        ],
                      ),
                    ),

                    // Products Grid
                    Expanded(
                      child: RefreshIndicator(
                        onRefresh: _loadMedicines,
                        color: AppTheme.primaryTeal,
                        child: _filteredMedicines.isEmpty
                            ? _buildEmptyState()
                            : GridView.builder(
                                padding: const EdgeInsets.all(16),
                                gridDelegate:
                                    const SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 2,
                                  childAspectRatio: 0.7,
                                  crossAxisSpacing: 16,
                                  mainAxisSpacing: 16,
                                ),
                                itemCount: _filteredMedicines.length,
                                itemBuilder: (context, index) {
                                  final medicine = _filteredMedicines[index];
                                  return _buildProductCard(theme, medicine);
                                },
                              ),
                      ),
                    ),
                  ],
                ),
    );
  }

  Widget _buildProductCard(ThemeData theme, Map<String, dynamic> medicine) {
    final bool hasDiscount = medicine['discount'] > 0;
    final bool isLowStock = medicine['stock'] < 10;
    final bool isPrescriptionRequired = !medicine['isOTC'];

    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Medicine Image & Discount Badge
          Expanded(
            flex: 3,
            child: Stack(
              children: [
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: AppTheme.primaryTeal.withOpacity(0.1),
                    borderRadius:
                        const BorderRadius.vertical(top: Radius.circular(16)),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        _getCategoryIcon(medicine['category']),
                        size: 40,
                        color: AppTheme.primaryTeal,
                      ),
                      if (isPrescriptionRequired)
                        Container(
                          margin: const EdgeInsets.only(top: 8),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppTheme.errorRed,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Text(
                            'Rx',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                if (hasDiscount)
                  Positioned(
                    top: 8,
                    left: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppTheme.errorRed,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        '${medicine['discount']}% OFF',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                if (isLowStock)
                  Positioned(
                    top: 8,
                    right: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppTheme.warningOrange,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Text(
                        'Low Stock',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          // Medicine Details
          Expanded(
            flex: 4,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Medicine Name
                  Text(
                    medicine['name'],
                    style: theme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),

                  // Manufacturer
                  Text(
                    medicine['manufacturer'],
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: Colors.grey[600],
                      fontSize: 11,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),

                  // Rating
                  Row(
                    children: [
                      const Icon(
                        Icons.star,
                        size: 12,
                        color: AppTheme.warningOrange,
                      ),
                      const SizedBox(width: 2),
                      Text(
                        '${medicine['rating']}',
                        style: theme.textTheme.bodySmall?.copyWith(
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '(${medicine['reviews']})',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: Colors.grey[500],
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),

                  // Price
                  Row(
                    children: [
                      Text(
                        '\$${medicine['price'].toStringAsFixed(2)}',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: AppTheme.primaryTeal,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                      if (hasDiscount) ...[
                        const SizedBox(width: 6),
                        Text(
                          '\$${medicine['originalPrice'].toStringAsFixed(2)}',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: Colors.grey[500],
                            decoration: TextDecoration.lineThrough,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ],
                  ),
                  const Spacer(),

                  // Add to Cart Button
                  SizedBox(
                    width: double.infinity,
                    height: 32,
                    child: ElevatedButton(
                      onPressed: medicine['stock'] > 0
                          ? () => _addToCart(medicine)
                          : null,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: medicine['stock'] > 0
                            ? AppTheme.primaryTeal
                            : Colors.grey[300],
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 0),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: Text(
                        medicine['stock'] > 0 ? 'Add to Cart' : 'Out of Stock',
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.search_off,
            size: 64,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            'No medicines found',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Colors.grey[600],
                  fontWeight: FontWeight.w500,
                ),
          ),
          const SizedBox(height: 8),
          Text(
            'Try adjusting your search or filters',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Colors.grey[500],
                ),
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _selectedCategory = 'All';
                _searchQuery = '';
                _searchController.clear();
              });
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryTeal,
              foregroundColor: Colors.white,
            ),
            child: const Text('Clear Filters'),
          ),
        ],
      ),
    );
  }

  IconData _getCategoryIcon(String category) {
    switch (category) {
      case 'Pain Relief':
        return Icons.healing;
      case 'Antibiotics':
        return Icons.biotech;
      case 'Vitamins':
        return Icons.local_pharmacy;
      case 'Cold & Flu':
        return Icons.air;
      case 'Heart':
        return Icons.favorite;
      case 'Diabetes':
        return Icons.water_drop;
      default:
        return Icons.medication;
    }
  }

  Future<void> _addToCart(Map<String, dynamic> medicine) async {
    try {
      await _apiService.initialize();

      final cartItem = {
        'medicineId': medicine['id'],
        'name': medicine['name'],
        'genericName': medicine['genericName'],
        'form': medicine['form'] ?? 'Tablet',
        'manufacturer': medicine['manufacturer'],
        'packSize': medicine['packSize'] ?? '1 unit',
        'price': medicine['price'],
        'originalPrice': medicine['originalPrice'],
        'quantity': 1,
        'expiryDate': medicine['expiryDate'] ??
            DateTime.now()
                .add(const Duration(days: 365))
                .toIso8601String()
                .split('T')[0],
        'batchNumber': medicine['batchNumber'] ?? 'N/A',
        'isOTC': medicine['isOTC'],
        'discount': medicine['discount'],
      };

      await _apiService.addToCart(cartItem);

      // Update cart count
      await _updateCartCount();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${medicine['name']} added to cart'),
            backgroundColor: AppTheme.successGreen,
            duration: const Duration(seconds: 2),
            action: SnackBarAction(
              label: 'View Cart',
              textColor: Colors.white,
              onPressed: () {
                AppRoutes.navigateTo(context, AppRoutes.cart);
              },
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to add to cart: ${e.toString()}'),
            backgroundColor: AppTheme.errorRed,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    }
  }

  Future<void> _updateCartCount() async {
    try {
      final cartItems = await _apiService.getCartItems();
      setState(() {
        _cartItemCount = cartItems.length;
      });
    } catch (e) {
      // Silently fail cart count update
      print('Failed to update cart count: $e');
    }
  }

  void _showFilterDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Filter Options'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Sort by:'),
              const SizedBox(height: 8),
              ListTile(
                title: const Text('Price: Low to High'),
                leading: Radio(
                    value: 'price_asc', groupValue: '', onChanged: (value) {}),
              ),
              ListTile(
                title: const Text('Price: High to Low'),
                leading: Radio(
                    value: 'price_desc', groupValue: '', onChanged: (value) {}),
              ),
              ListTile(
                title: const Text('Rating: High to Low'),
                leading: Radio(
                    value: 'rating_desc',
                    groupValue: '',
                    onChanged: (value) {}),
              ),
              ListTile(
                title: const Text('Name: A to Z'),
                leading: Radio(
                    value: 'name_asc', groupValue: '', onChanged: (value) {}),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pop(),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryTeal,
                foregroundColor: Colors.white,
              ),
              child: const Text('Apply'),
            ),
          ],
        );
      },
    );
  }
}
