import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../../services/api_service.dart';
import '../../utils/app_theme.dart';

class RequestMedicineScreen extends StatefulWidget {
  const RequestMedicineScreen({super.key});

  @override
  State<RequestMedicineScreen> createState() => _RequestMedicineScreenState();
}

class _RequestMedicineScreenState extends State<RequestMedicineScreen> {
  final _formKey = GlobalKey<FormState>();
  final _medicineNameController = TextEditingController();
  final _genericNameController = TextEditingController();
  final _packSizeController = TextEditingController();
  final _notesController = TextEditingController();
  final ApiService _apiService = ApiService();

  String _selectedForm = 'Tablet';
  String _selectedUrgency = 'Medium';
  File? _selectedImage;
  bool _isSubmitting = false;

  final ImagePicker _picker = ImagePicker();

  final List<String> _forms = [
    'Tablet',
    'Capsule',
    'Syrup',
    'Injection',
    'Cream',
    'Ointment',
    'Drops',
    'Inhaler',
    'Patch',
    'Powder',
    'Other',
  ];

  final List<Map<String, dynamic>> _urgencyLevels = [
    {
      'value': 'Low',
      'label': 'Low Priority',
      'description': 'Can wait 3-7 days',
      'color': AppTheme.successGreen,
      'icon': Icons.schedule,
    },
    {
      'value': 'Medium',
      'label': 'Medium Priority',
      'description': 'Needed within 1-3 days',
      'color': AppTheme.warningOrange,
      'icon': Icons.warning_amber,
    },
    {
      'value': 'High',
      'label': 'High Priority',
      'description': 'Needed within 24 hours',
      'color': AppTheme.errorRed,
      'icon': Icons.priority_high,
    },
    {
      'value': 'Urgent',
      'label': 'Urgent',
      'description': 'Needed immediately',
      'color': AppTheme.errorRed,
      'icon': Icons.emergency,
    },
  ];

  @override
  void dispose() {
    _medicineNameController.dispose();
    _genericNameController.dispose();
    _packSizeController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading:
                  const Icon(Icons.camera_alt, color: AppTheme.primaryTeal),
              title: const Text('Take Photo'),
              onTap: () async {
                Navigator.pop(context);
                final XFile? photo = await _picker.pickImage(
                  source: ImageSource.camera,
                  maxWidth: 800,
                  maxHeight: 800,
                  imageQuality: 80,
                );
                if (photo != null) {
                  setState(() {
                    _selectedImage = File(photo.path);
                  });
                }
              },
            ),
            ListTile(
              leading:
                  const Icon(Icons.photo_library, color: AppTheme.primaryTeal),
              title: const Text('Choose from Gallery'),
              onTap: () async {
                Navigator.pop(context);
                final XFile? photo = await _picker.pickImage(
                  source: ImageSource.gallery,
                  maxWidth: 800,
                  maxHeight: 800,
                  imageQuality: 80,
                );
                if (photo != null) {
                  setState(() {
                    _selectedImage = File(photo.path);
                  });
                }
              },
            ),
            if (_selectedImage != null)
              ListTile(
                leading: const Icon(Icons.delete, color: AppTheme.errorRed),
                title: const Text('Remove Image'),
                onTap: () {
                  Navigator.pop(context);
                  setState(() {
                    _selectedImage = null;
                  });
                },
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        title: const Text(
          'Request Medicine',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: AppTheme.warningOrange,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            onPressed: _clearForm,
            icon: const Icon(Icons.refresh),
            tooltip: 'Reset Form',
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: Column(
          children: [
            // Header Info
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              color: AppTheme.warningOrange.withOpacity(0.1),
              child: Column(
                children: [
                  const Icon(
                    Icons.add_shopping_cart,
                    size: 48,
                    color: AppTheme.warningOrange,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Request Unavailable Medicine',
                    style: theme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: AppTheme.warningOrange,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Request medicines that are not currently available in our inventory',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: AppTheme.darkGray.withOpacity(0.7),
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),

            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Image Upload Section
                    _buildImageUploadSection(),
                    const SizedBox(height: 24),

                    // Medicine Details
                    _buildSectionHeader('Medicine Details', Icons.medication),
                    const SizedBox(height: 16),

                    _buildTextField(
                      controller: _medicineNameController,
                      label: 'Medicine Name *',
                      hint: 'e.g., Amoxicillin 250mg',
                      icon: Icons.medication,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter medicine name';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    _buildTextField(
                      controller: _genericNameController,
                      label: 'Generic Name',
                      hint: 'e.g., Amoxicillin',
                      icon: Icons.science,
                    ),
                    const SizedBox(height: 16),

                    _buildFormDropdown(),
                    const SizedBox(height: 16),

                    _buildTextField(
                      controller: _packSizeController,
                      label: 'Pack Size',
                      hint: 'e.g., 20 capsules, 100ml bottle',
                      icon: Icons.inventory_2,
                    ),
                    const SizedBox(height: 24),

                    // Urgency Level
                    _buildSectionHeader(
                        'Request Priority', Icons.priority_high),
                    const SizedBox(height: 16),
                    _buildUrgencySelector(),
                    const SizedBox(height: 24),

                    // Additional Notes
                    _buildSectionHeader('Additional Information', Icons.notes),
                    const SizedBox(height: 16),

                    _buildTextField(
                      controller: _notesController,
                      label: 'Additional Notes',
                      hint:
                          'Any additional information about the medicine, dosage, or specific requirements...',
                      icon: Icons.description,
                      maxLines: 4,
                    ),
                    const SizedBox(height: 32),
                  ],
                ),
              ),
            ),

            // Bottom Action Buttons
            _buildBottomActions(),
          ],
        ),
      ),
    );
  }

  Widget _buildImageUploadSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.camera_alt,
                color: AppTheme.warningOrange,
                size: 24,
              ),
              const SizedBox(width: 8),
              Text(
                'Medicine Image',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: AppTheme.warningOrange,
                    ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Upload an image of the medicine packaging or prescription',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Colors.grey[600],
                ),
          ),
          const SizedBox(height: 16),
          if (_selectedImage != null)
            Container(
              width: double.infinity,
              height: 200,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey[300]!),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  _selectedImage!,
                  fit: BoxFit.cover,
                ),
              ),
            )
          else
            Container(
              width: double.infinity,
              height: 120,
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.grey[300]!,
                  style: BorderStyle.solid,
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.add_a_photo,
                    size: 48,
                    color: Colors.grey[400],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'No image selected',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.grey[600],
                        ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _pickImage,
                  icon: Icon(
                    _selectedImage != null ? Icons.edit : Icons.camera_alt,
                    size: 20,
                  ),
                  label: Text(
                      _selectedImage != null ? 'Change Image' : 'Add Image'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppTheme.warningOrange,
                    side: const BorderSide(color: AppTheme.warningOrange),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
              if (_selectedImage != null) ...[
                const SizedBox(width: 16),
                OutlinedButton.icon(
                  onPressed: () {
                    setState(() {
                      _selectedImage = null;
                    });
                  },
                  icon: const Icon(Icons.delete, size: 20),
                  label: const Text('Remove'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppTheme.errorRed,
                    side: const BorderSide(color: AppTheme.errorRed),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Row(
      children: [
        Icon(
          icon,
          color: AppTheme.warningOrange,
          size: 24,
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
                color: AppTheme.warningOrange,
              ),
        ),
      ],
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    String? Function(String?)? validator,
    int maxLines = 1,
  }) {
    return TextFormField(
      controller: controller,
      validator: validator,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Icon(icon, color: AppTheme.warningOrange),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppTheme.warningOrange, width: 2),
        ),
      ),
    );
  }

  Widget _buildFormDropdown() {
    return DropdownButtonFormField<String>(
      value: _selectedForm,
      decoration: InputDecoration(
        labelText: 'Form',
        prefixIcon: const Icon(Icons.category, color: AppTheme.warningOrange),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppTheme.warningOrange, width: 2),
        ),
      ),
      items: _forms.map((form) {
        return DropdownMenuItem(
          value: form,
          child: Row(
            children: [
              Icon(
                _getFormIcon(form),
                size: 20,
                color: AppTheme.warningOrange,
              ),
              const SizedBox(width: 8),
              Text(form),
            ],
          ),
        );
      }).toList(),
      onChanged: (value) {
        setState(() {
          _selectedForm = value!;
        });
      },
    );
  }

  Widget _buildUrgencySelector() {
    return Column(
      children: _urgencyLevels.map((urgency) {
        final isSelected = _selectedUrgency == urgency['value'];
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isSelected ? urgency['color'] : Colors.grey[300]!,
              width: isSelected ? 2 : 1,
            ),
            color: isSelected
                ? urgency['color'].withOpacity(0.1)
                : Colors.transparent,
          ),
          child: RadioListTile<String>(
            value: urgency['value'],
            groupValue: _selectedUrgency,
            onChanged: (value) {
              setState(() {
                _selectedUrgency = value!;
              });
            },
            title: Row(
              children: [
                Icon(
                  urgency['icon'],
                  color: urgency['color'],
                  size: 20,
                ),
                const SizedBox(width: 8),
                Text(
                  urgency['label'],
                  style: TextStyle(
                    fontWeight:
                        isSelected ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
              ],
            ),
            subtitle: Text(
              urgency['description'],
              style: TextStyle(
                color: isSelected ? urgency['color'] : Colors.grey[600],
                fontSize: 12,
              ),
            ),
            activeColor: urgency['color'],
          ),
        );
      }).toList(),
    );
  }

  Future<void> _submitRequest() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isSubmitting = true;
    });

    try {
      await _apiService.initialize();

      String? imageUrl;

      // Upload image if selected
      if (_selectedImage != null) {
        try {
          final imageResponse =
              await _apiService.uploadMedicineImage(_selectedImage!.path);
          imageUrl = imageResponse['imageUrl'] ?? imageResponse['url'];
        } catch (e) {
          // Continue without image if upload fails
          print('Image upload failed: $e');
        }
      }

      // Prepare request data for API
      final requestData = {
        'medicineName': _medicineNameController.text.trim(),
        'genericName': _genericNameController.text.trim(),
        'form': _selectedForm,
        'packSize': _packSizeController.text.trim(),
        'urgency': _selectedUrgency.toLowerCase(),
        'notes': _notesController.text.trim(),
        'status': 'pending',
        'imageUrl': imageUrl,
        'requestedAt': DateTime.now().toIso8601String(),
        'pharmacyId': 'current_pharmacy', // This should come from auth context
      };

      // Call API to create medicine request
      final response = await _apiService.createMedicineRequest(requestData);

      if (mounted) {
        // Show success message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                const Icon(Icons.check_circle, color: Colors.white),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Request for "${_medicineNameController.text}" submitted successfully!',
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
            backgroundColor: AppTheme.successGreen,
            duration: const Duration(seconds: 3),
          ),
        );

        // Clear form and navigate back
        _clearForm();
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) {
        // Show error message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                const Icon(Icons.error, color: Colors.white),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Failed to submit request: ${e.toString()}',
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
            backgroundColor: AppTheme.errorRed,
            duration: const Duration(seconds: 5),
            action: SnackBarAction(
              label: 'Retry',
              textColor: Colors.white,
              onPressed: _submitRequest,
            ),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isSubmitting = false;
        });
      }
    }
  }

  void _clearForm() {
    _medicineNameController.clear();
    _genericNameController.clear();
    _packSizeController.clear();
    _notesController.clear();
    setState(() {
      _selectedForm = 'Tablet';
      _selectedUrgency = 'Medium';
      _selectedImage = null;
    });
  }

  Widget _buildBottomActions() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border(
          top: BorderSide(color: Colors.grey[300]!),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton(
              onPressed: () => Navigator.of(context).pop(),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppTheme.warningOrange,
                side: const BorderSide(color: AppTheme.warningOrange),
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child: const Text('Cancel'),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            flex: 2,
            child: ElevatedButton(
              onPressed: _isSubmitting ? null : _submitRequest,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.warningOrange,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child: _isSubmitting
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    )
                  : const Text(
                      'Submit Request',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  IconData _getFormIcon(String form) {
    switch (form.toLowerCase()) {
      case 'tablet':
        return Icons.medication;
      case 'capsule':
        return Icons.medication_liquid;
      case 'syrup':
        return Icons.local_drink;
      case 'injection':
        return Icons.colorize;
      case 'cream':
        return Icons.healing;
      case 'ointment':
        return Icons.healing;
      case 'drops':
        return Icons.water_drop;
      case 'inhaler':
        return Icons.air;
      case 'patch':
        return Icons.medical_services;
      case 'powder':
        return Icons.scatter_plot;
      default:
        return Icons.medication;
    }
  }
}
