import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/theme_provider.dart';
import '../../utils/app_theme.dart';
import '../../utils/app_routes.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notificationsEnabled = true;
  bool _emailNotifications = true;
  bool _pushNotifications = true;
  bool _orderUpdates = true;
  bool _promotionalOffers = false;
  String _language = 'English';
  String _currency = 'USD';

  final List<String> _languages = ['English', 'Arabic', 'French', 'Spanish'];
  final List<String> _currencies = ['USD', 'EUR', 'GBP', 'SAR', 'EGP'];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Account Settings
            _buildSectionHeader('Account Settings', theme),
            _buildAccountSettings(theme),

            const SizedBox(height: 24),

            // Notifications
            _buildSectionHeader('Notifications', theme),
            _buildNotificationSettings(theme),

            const SizedBox(height: 24),

            // App Preferences
            _buildSectionHeader('App Preferences', theme),
            _buildAppPreferences(theme),

            const SizedBox(height: 24),

            // Privacy & Security
            _buildSectionHeader('Privacy & Security', theme),
            _buildPrivacySettings(theme),

            const SizedBox(height: 24),

            // Support & Help
            _buildSectionHeader('Support & Help', theme),
            _buildSupportSettings(theme),

            const SizedBox(height: 24),

            // Administration (for managers)
            _buildSectionHeader('Administration', theme),
            _buildAdministrationSettings(theme),

            const SizedBox(height: 24),

            // About
            _buildSectionHeader('About', theme),
            _buildAboutSettings(theme),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        title,
        style: theme.textTheme.titleMedium?.copyWith(
          fontWeight: FontWeight.bold,
          color: AppTheme.primaryGreen,
        ),
      ),
    );
  }

  Widget _buildAccountSettings(ThemeData theme) {
    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Column(
        children: [
          _buildSettingTile(
            icon: Icons.person,
            title: 'Edit Profile',
            subtitle: 'Update your personal information',
            onTap: () {
              AppRoutes.navigateTo(context, AppRoutes.editProfile);
            },
            theme: theme,
          ),
          _buildDivider(theme),
          _buildSettingTile(
            icon: Icons.lock,
            title: 'Change Password',
            subtitle: 'Update your account password',
            onTap: () {
              AppRoutes.navigateTo(context, AppRoutes.forgotPassword);
            },
            theme: theme,
          ),
          _buildDivider(theme),
          _buildSettingTile(
            icon: Icons.location_on,
            title: 'Delivery Addresses',
            subtitle: 'Manage your delivery addresses',
            onTap: () {
              // TODO: Navigate to addresses
            },
            theme: theme,
          ),
          _buildDivider(theme),
          _buildSettingTile(
            icon: Icons.payment,
            title: 'Payment Methods',
            subtitle: 'Manage your payment options',
            onTap: () {
              // TODO: Navigate to payment methods
            },
            theme: theme,
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationSettings(ThemeData theme) {
    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Column(
        children: [
          SwitchListTile(
            title: const Text('Enable Notifications'),
            subtitle: const Text('Receive app notifications'),
            value: _notificationsEnabled,
            onChanged: (value) {
              setState(() {
                _notificationsEnabled = value;
                if (!value) {
                  _emailNotifications = false;
                  _pushNotifications = false;
                  _orderUpdates = false;
                  _promotionalOffers = false;
                }
              });
            },
            secondary: const Icon(Icons.notifications),
          ),
          if (_notificationsEnabled) ...[
            _buildDivider(theme),
            SwitchListTile(
              title: const Text('Email Notifications'),
              subtitle: const Text('Receive updates via email'),
              value: _emailNotifications,
              onChanged: (value) {
                setState(() {
                  _emailNotifications = value;
                });
              },
              secondary: const Icon(Icons.email),
            ),
            _buildDivider(theme),
            SwitchListTile(
              title: const Text('Push Notifications'),
              subtitle: const Text('Receive push notifications'),
              value: _pushNotifications,
              onChanged: (value) {
                setState(() {
                  _pushNotifications = value;
                });
              },
              secondary: const Icon(Icons.phone_android),
            ),
            _buildDivider(theme),
            SwitchListTile(
              title: const Text('Order Updates'),
              subtitle: const Text('Get notified about order status'),
              value: _orderUpdates,
              onChanged: (value) {
                setState(() {
                  _orderUpdates = value;
                });
              },
              secondary: const Icon(Icons.local_shipping),
            ),
            _buildDivider(theme),
            SwitchListTile(
              title: const Text('Promotional Offers'),
              subtitle: const Text('Receive special offers and discounts'),
              value: _promotionalOffers,
              onChanged: (value) {
                setState(() {
                  _promotionalOffers = value;
                });
              },
              secondary: const Icon(Icons.local_offer),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildAppPreferences(ThemeData theme) {
    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Column(
        children: [
          Consumer<ThemeProvider>(
            builder: (context, themeProvider, child) {
              return SwitchListTile(
                title: const Text('Dark Mode'),
                subtitle: const Text('Use dark theme'),
                value: themeProvider.themeMode == ThemeMode.dark,
                onChanged: (value) {
                  themeProvider.setThemeMode(
                    value ? ThemeMode.dark : ThemeMode.light,
                  );
                },
                secondary: const Icon(Icons.dark_mode),
              );
            },
          ),
          _buildDivider(theme),
          ListTile(
            leading: const Icon(Icons.language),
            title: const Text('Language'),
            subtitle: Text(_language),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              _showLanguageDialog(theme);
            },
          ),
          _buildDivider(theme),
          ListTile(
            leading: const Icon(Icons.attach_money),
            title: const Text('Currency'),
            subtitle: Text(_currency),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              _showCurrencyDialog(theme);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildPrivacySettings(ThemeData theme) {
    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Column(
        children: [
          _buildSettingTile(
            icon: Icons.privacy_tip,
            title: 'Privacy Policy',
            subtitle: 'Read our privacy policy',
            onTap: () {
              // TODO: Navigate to privacy policy
            },
            theme: theme,
          ),
          _buildDivider(theme),
          _buildSettingTile(
            icon: Icons.description,
            title: 'Terms of Service',
            subtitle: 'Read our terms of service',
            onTap: () {
              // TODO: Navigate to terms of service
            },
            theme: theme,
          ),
          _buildDivider(theme),
          _buildSettingTile(
            icon: Icons.delete_forever,
            title: 'Delete Account',
            subtitle: 'Permanently delete your account',
            onTap: () {
              _showDeleteAccountDialog(theme);
            },
            theme: theme,
            isDestructive: true,
          ),
        ],
      ),
    );
  }

  Widget _buildSupportSettings(ThemeData theme) {
    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Column(
        children: [
          _buildSettingTile(
            icon: Icons.support_agent,
            title: 'Contact Support',
            subtitle: 'Get help from our support team',
            onTap: () {
              AppRoutes.navigateTo(context, AppRoutes.supportChat);
            },
            theme: theme,
          ),
          _buildDivider(theme),
          _buildSettingTile(
            icon: Icons.help,
            title: 'Help Center',
            subtitle: 'Browse help articles and FAQs',
            onTap: () {
              // TODO: Navigate to help center
            },
            theme: theme,
          ),
          _buildDivider(theme),
          _buildSettingTile(
            icon: Icons.feedback,
            title: 'Send Feedback',
            subtitle: 'Share your thoughts with us',
            onTap: () {
              // TODO: Navigate to feedback form
            },
            theme: theme,
          ),
        ],
      ),
    );
  }

  Widget _buildAdministrationSettings(ThemeData theme) {
    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Column(
        children: [
          _buildSettingTile(
            icon: Icons.analytics,
            title: 'Reports & Analytics',
            subtitle: 'View detailed reports and analytics',
            onTap: () {
              AppRoutes.navigateTo(context, AppRoutes.reports);
            },
            theme: theme,
          ),
          _buildDivider(theme),
          _buildSettingTile(
            icon: Icons.people,
            title: 'User Management',
            subtitle: 'Manage users and permissions',
            onTap: () {
              AppRoutes.navigateTo(context, AppRoutes.userManagement);
            },
            theme: theme,
          ),
          _buildDivider(theme),
          _buildSettingTile(
            icon: Icons.local_shipping,
            title: 'Delivery Management',
            subtitle: 'Manage delivery orders and tracking',
            onTap: () {
              AppRoutes.navigateTo(context, AppRoutes.delivery);
            },
            theme: theme,
          ),
        ],
      ),
    );
  }

  Widget _buildAboutSettings(ThemeData theme) {
    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Column(
        children: [
          ListTile(
            leading: const Icon(Icons.info),
            title: const Text('App Version'),
            subtitle: const Text('1.0.0'),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              // TODO: Show version details
            },
          ),
          _buildDivider(theme),
          _buildSettingTile(
            icon: Icons.update,
            title: 'Check for Updates',
            subtitle: 'Check for app updates',
            onTap: () {
              // TODO: Check for updates
            },
            theme: theme,
          ),
          _buildDivider(theme),
          _buildSettingTile(
            icon: Icons.share,
            title: 'Share App',
            subtitle: 'Share Recyleto with friends',
            onTap: () {
              AppRoutes.navigateTo(context, AppRoutes.about);
            },
            theme: theme,
          ),
        ],
      ),
    );
  }

  Widget _buildSettingTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    required ThemeData theme,
    bool isDestructive = false,
  }) {
    return ListTile(
      leading: Icon(
        icon,
        color: isDestructive ? AppTheme.errorRed : AppTheme.primaryGreen,
      ),
      title: Text(
        title,
        style: TextStyle(
          color: isDestructive ? AppTheme.errorRed : null,
        ),
      ),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.arrow_forward_ios),
      onTap: onTap,
    );
  }

  Widget _buildDivider(ThemeData theme) {
    return Divider(
      height: 1,
      color: Colors.grey[300],
      indent: 56,
    );
  }

  void _showLanguageDialog(ThemeData theme) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Select Language'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: _languages
              .map((language) => RadioListTile<String>(
                    title: Text(language),
                    value: language,
                    groupValue: _language,
                    onChanged: (value) {
                      setState(() {
                        _language = value!;
                      });
                      Navigator.of(context).pop();
                    },
                  ))
              .toList(),
        ),
      ),
    );
  }

  void _showCurrencyDialog(ThemeData theme) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Select Currency'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: _currencies
              .map((currency) => RadioListTile<String>(
                    title: Text(currency),
                    value: currency,
                    groupValue: _currency,
                    onChanged: (value) {
                      setState(() {
                        _currency = value!;
                      });
                      Navigator.of(context).pop();
                    },
                  ))
              .toList(),
        ),
      ),
    );
  }

  void _showDeleteAccountDialog(ThemeData theme) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Account'),
        content: const Text(
          'Are you sure you want to delete your account? This action cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              // TODO: Implement account deletion
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Account deletion requested'),
                  backgroundColor: AppTheme.warningOrange,
                ),
              );
            },
            style: TextButton.styleFrom(
              foregroundColor: AppTheme.errorRed,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}
